<?php
/**
 * Freechat Extension - Admin View - Forums List
 */

defined('_FFEXEC') or die;
?>
<div class="container-fluid">
  <div class="row mb-3">
    <div class="col">
      <h1 class="h3 mb-0">
        <i class="fa-solid fa-comments me-2"></i>
        <?php echo Language::translate('COM_FREECHAT_FORUMS'); ?>
      </h1>
    </div>
    <div class="col-auto">
      <a href="index.php?option=freechat&view=forums&task=add" class="btn btn-primary">
        <i class="fa-solid fa-plus me-1"></i>
        <?php echo Language::translate('COM_FREECHAT_FORUM_NEW'); ?>
      </a>
    </div>
  </div>

  <div class="card">
    <div class="card-body">
      <?php if (empty($this->forums)): ?>
        <div class="alert alert-info">
          <?php echo Language::translate('COM_FREECHAT_FORUM_NO_FORUMS'); ?>
        </div>
      <?php else: ?>
        <div class="table-responsive">
          <table class="table table-hover align-middle">
            <thead>
              <tr>
                <th><?php echo Language::translate('COM_FREECHAT_FORUMS'); ?></th>
                <th><?php echo Language::translate('COM_FREECHAT_CATEGORIES'); ?></th>
                <th><?php echo Language::translate('COM_FREECHAT_SPACES'); ?></th>
                <th class="text-center"><?php echo Language::translate('COM_FREECHAT_SPACE_ORDERING'); ?></th>
                <th class="text-center"><?php echo Language::translate('COM_FREECHAT_SPACE_STATE'); ?></th>
                <th class="text-end"><?php echo Language::translate('COM_FREECHAT_EDIT'); ?></th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($this->forums as $forum): ?>
                <tr>
                  <td>
                    <strong><?php echo htmlspecialchars($forum->title); ?></strong>
                    <br>
                    <small class="text-muted"><?php echo htmlspecialchars($forum->slug); ?></small>
                  </td>
                  <td><?php echo htmlspecialchars($forum->category_title); ?></td>
                  <td><?php echo htmlspecialchars($forum->space_title); ?></td>
                  <td class="text-center"><?php echo $forum->ordering; ?></td>
                  <td class="text-center">
                    <button class="btn btn-sm btn-link toggle-state"
                            data-id="<?php echo $forum->id; ?>"
                            data-state="<?php echo $forum->state; ?>"
                            data-url="index.php?option=freechat&view=forums&task=toggleState">
                      <i class="fa-solid <?php echo $forum->state ? 'fa-circle-check text-success' : 'fa-circle-xmark text-danger'; ?> fa-lg"></i>
                    </button>
                  </td>
                  <td class="text-end">
                    <a href="index.php?option=freechat&view=forums&task=edit&id=<?php echo $forum->id; ?>" class="btn btn-sm btn-outline-primary">
                      <i class="fa-solid fa-pencil"></i>
                    </a>
                    <a href="index.php?option=freechat&view=forums&task=delete&id=<?php echo $forum->id; ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('<?php echo Language::translate('COM_FREECHAT_CONFIRM_DELETE'); ?>')">
                      <i class="fa-solid fa-trash"></i>
                    </a>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
  document.querySelectorAll('.toggle-state').forEach(function(btn) {
    btn.addEventListener('click', function(e) {
      e.preventDefault();
      var id = this.dataset.id;
      var currentState = parseInt(this.dataset.state);
      var newState = currentState ? 0 : 1;
      var url = this.dataset.url + '&id=' + id + '&state=' + newState;
      
      fetch(url)
        .then(function(response) { return response.json(); })
        .then(function(data) {
          if (data.success) {
            var icon = btn.querySelector('i');
            icon.className = 'fa-solid ' + data.icon + ' fa-lg';
            btn.dataset.state = newState;
          }
        });
    });
  });
});
</script>
