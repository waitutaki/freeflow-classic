-- Freechat Extension Uninstall Script
-- Version: 1.0.0
-- Date: 2025-01-06

-- Drop tables in reverse order of dependencies
DROP TABLE IF EXISTS `#_ext_freechat_notifications`;
DROP TABLE IF EXISTS `#_ext_freechat_subscriptions`;
DROP TABLE IF EXISTS `#_ext_freechat_reports`;
DROP TABLE IF EXISTS `#_ext_freechat_attachments`;
DROP TABLE IF EXISTS `#_ext_freechat_reactions`;
DROP TABLE IF EXISTS `#_ext_freechat_revisions`;
DROP TABLE IF EXISTS `#_ext_freechat_posts`;
DROP TABLE IF EXISTS `#_ext_freechat_topics`;
DROP TABLE IF EXISTS `#_ext_freechat_forums`;
DROP TABLE IF EXISTS `#_ext_freechat_categories`;
DROP TABLE IF EXISTS `#_ext_freechat_spaces`;
