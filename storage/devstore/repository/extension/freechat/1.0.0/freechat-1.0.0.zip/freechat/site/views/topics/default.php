<?php
/**
 * Freechat Extension - Site View - Topics List
 */

defined('_FFEXEC') or die;

$forum = $this->forum;
$pagination = $this->pagination;
?>
<div class="freechat-container">
  <nav aria-label="breadcrumb" class="mb-3">
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="index.php?option=freechat"><?php echo Language::translate('COM_FREECHAT_FORUM_INDEX'); ?></a></li>
      <li class="breadcrumb-item active"><?php echo htmlspecialchars($forum->title); ?></li>
    </ol>
  </nav>

  <div class="d-flex justify-content-between align-items-center mb-3">
    <h1 class="h4 mb-0">
      <i class="fa-solid fa-comments me-2"></i>
      <?php echo htmlspecialchars($forum->title); ?>
    </h1>
    <?php if (\Freeflow\Core\User::getInstance()->can('freechat.topics.create')): ?>
      <a href="index.php?option=freechat&view=topics&task=create&forum_id=<?php echo $forum->id; ?>" class="btn btn-primary btn-sm">
        <i class="fa-solid fa-plus me-1"></i>
        <?php echo Language::translate('COM_FREECHAT_TOPIC_NEW'); ?>
      </a>
    <?php endif; ?>
  </div>

  <?php if ($forum->description): ?>
    <p class="text-muted mb-3"><?php echo htmlspecialchars($forum->description); ?></p>
  <?php endif; ?>

  <div class="card">
    <div class="card-body p-0">
      <?php if (empty($this->topics)): ?>
        <div class="p-3 text-center text-muted">
          <?php echo Language::translate('COM_FREECHAT_TOPIC_NO_TOPICS'); ?>
        </div>
      <?php else: ?>
        <div class="table-responsive">
          <table class="table table-hover mb-0">
            <thead class="table-light">
              <tr>
                <th><?php echo Language::translate('COM_FREECHAT_TOPICS'); ?></th>
                <th class="text-center" style="width: 80px;"><?php echo Language::translate('COM_FREECHAT_POSTS'); ?></th>
                <th class="text-center" style="width: 80px;"><?php echo Language::translate('COM_FREECHAT_TOPIC_VIEW_COUNT'); ?></th>
                <th style="width: 200px;"><?php echo Language::translate('COM_FREECHAT_TOPIC_LAST_POST'); ?></th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($this->topics as $topic): ?>
                <tr>
                  <td>
                    <a href="index.php?option=freechat&view=topics&task=view&id=<?php echo $topic->id; ?>" class="text-decoration-none">
                      <?php if ($topic->type == 'sticky'): ?>
                        <i class="fa-solid fa-thumbtack text-warning me-1" title="<?php echo Language::translate('COM_FREECHAT_TOPIC_STICKY'); ?>"></i>
                      <?php elseif ($topic->type == 'announcement'): ?>
                        <i class="fa-solid fa-bullhorn text-info me-1" title="<?php echo Language::translate('COM_FREECHAT_TOPIC_ANNOUNCEMENT'); ?>"></i>
                      <?php endif; ?>
                      
                      <?php if ($topic->state == 'locked'): ?>
                        <i class="fa-solid fa-lock text-danger me-1" title="<?php echo Language::translate('COM_FREECHAT_TOPIC_LOCKED'); ?>"></i>
                      <?php endif; ?>
                      
                      <strong><?php echo htmlspecialchars($topic->title); ?></strong>
                    </a>
                  </td>
                  <td class="text-center"><?php echo $topic->post_count; ?></td>
                  <td class="text-center"><?php echo $topic->view_count; ?></td>
                  <td class="small text-muted">
                    <?php if ($topic->last_post_at): ?>
                      <?php echo date('M d, Y H:i', strtotime($topic->last_post_at)); ?>
                    <?php else: ?>
                      -
                    <?php endif; ?>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>
    </div>
  </div>

  <?php if ($pagination['pages'] > 1): ?>
    <nav class="mt-3">
      <ul class="pagination justify-content-center mb-0">
        <?php if ($pagination['page'] > 1): ?>
          <li class="page-item">
            <a class="page-link" href="index.php?option=freechat&view=topics&forum_id=<?php echo $forum->id; ?>&page=<?php echo $pagination['page'] - 1; ?>">
              <?php echo Language::translate('COM_FREECHAT_PAGINATION_PREVIOUS'); ?>
            </a>
          </li>
        <?php endif; ?>
        
        <?php for ($i = 1; $i <= $pagination['pages']; $i++): ?>
          <li class="page-item <?php echo $i == $pagination['page'] ? 'active' : ''; ?>">
            <a class="page-link" href="index.php?option=freechat&view=topics&forum_id=<?php echo $forum->id; ?>&page=<?php echo $i; ?>">
              <?php echo $i; ?>
            </a>
          </li>
        <?php endfor; ?>
        
        <?php if ($pagination['page'] < $pagination['pages']): ?>
          <li class="page-item">
            <a class="page-link" href="index.php?option=freechat&view=topics&forum_id=<?php echo $forum->id; ?>&page=<?php echo $pagination['page'] + 1; ?>">
              <?php echo Language::translate('COM_FREECHAT_PAGINATION_NEXT'); ?>
            </a>
          </li>
        <?php endif; ?>
      </ul>
    </nav>
  <?php endif; ?>
</div>
