<?php
/**
 * Freechat Extension - User Activity Element
 * Displays user forum activity
 */

defined('_FFEXEC') or die;

use Freeflow\Core\Database;
use Freeflow\Core\Language;
use Freeflow\Core\User;

$db = Database::getInstance();
$user = User::getInstance();

if (!$user->id) {
  return; // Don't show for guests
}

$limit = $params->get('limit', 5);

// Get user's recent posts
$posts = $db->getQuery(true)
  ->select('p.*')
  ->select('t.title as topic_title, t.id as topic_id')
  ->from('#_ext_freechat_posts p')
  ->leftJoin('#_ext_freechat_topics t ON p.topic_id = t.id')
  ->where('p.author_id = ' . $user->id)
  ->where('p.state = ' . $db->quote('published'))
  ->order('p.created_at DESC')
  ->setLimit($limit)
  ->loadObjectList();

// Get user's topic count
$topicCount = $db->getQuery(true)
  ->select('COUNT(*)')
  ->from('#_ext_freechat_topics')
  ->where('created_by = ' . $user->id)
  ->loadResult();

// Get user's post count
$postCount = $db->getQuery(true)
  ->select('COUNT(*)')
  ->from('#_ext_freechat_posts')
  ->where('author_id = ' . $user->id)
  ->loadResult();
?>
<div class="freechat-element freechat-user-activity">
  <div class="card">
    <div class="card-header">
      <h6 class="mb-0">
        <i class="fa-solid fa-user me-2"></i>
        <?php echo Language::translate('COM_FREECHAT_PROFILE_POSTS'); ?>
      </h6>
    </div>
    <div class="card-body">
      <div class="row text-center mb-3">
        <div class="col-6">
          <div class="h4 mb-0"><?php echo $topicCount; ?></div>
          <small class="text-muted"><?php echo Language::translate('COM_FREECHAT_PROFILE_TOPICS'); ?></small>
        </div>
        <div class="col-6">
          <div class="h4 mb-0"><?php echo $postCount; ?></div>
          <small class="text-muted"><?php echo Language::translate('COM_FREECHAT_POSTS'); ?></small>
        </div>
      </div>
      
      <hr>
      
      <h6 class="mb-2"><?php echo Language::translate('COM_FREECHAT_PROFILE_POSTS'); ?></h6>
      
      <?php if (empty($posts)): ?>
        <p class="text-muted small mb-0"><?php echo Language::translate('COM_FREECHAT_NOT_FOUND'); ?></p>
      <?php else: ?>
        <ul class="list-group list-group-flush">
          <?php foreach ($posts as $post): ?>
            <li class="list-group-item px-0 py-2">
              <a href="index.php?option=freechat&view=topics&task=view&id=<?php echo $post->topic_id; ?>#post-<?php echo $post->id; ?>" class="text-decoration-none small">
                <div class="text-truncate"><?php echo htmlspecialchars($post->topic_title); ?></div>
                <small class="text-muted">
                  <?php echo date('M d, Y H:i', strtotime($post->created_at)); ?>
                </small>
              </a>
            </li>
          <?php endforeach; ?>
        </ul>
      <?php endif; ?>
    </div>
  </div>
</div>
