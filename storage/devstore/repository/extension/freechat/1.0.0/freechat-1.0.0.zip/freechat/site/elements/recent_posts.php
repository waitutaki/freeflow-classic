<?php
/**
 * Freechat Extension - Recent Posts Element
 * Displays recent forum posts
 */

defined('_FFEXEC') or die;

use Freeflow\Core\Database;
use Freeflow\Core\Language;

$db = Database::getInstance();

$limit = $params->get('limit', 5);

$query = $db->getQuery(true)
  ->select('p.*')
  ->select('t.title as topic_title, t.id as topic_id')
  ->select('u.name as author_name')
  ->from('#_ext_freechat_posts p')
  ->leftJoin('#_ext_freechat_topics t ON p.topic_id = t.id')
  ->leftJoin('#_users u ON p.author_id = u.id')
  ->where('p.state = ' . $db->quote('published'))
  ->where('t.state IN (\'open\',\'locked\')')
  ->where('t.is_private = 0')
  ->order('p.created_at DESC')
  ->setLimit($limit);

$posts = $db->setQuery($query)->loadObjectList();
?>
<div class="freechat-element freechat-recent-posts">
  <div class="card">
    <div class="card-header">
      <h6 class="mb-0">
        <i class="fa-solid fa-comments me-2"></i>
        <?php echo Language::translate('COM_FREECHAT_ELEMENT_RECENT_POSTS'); ?>
      </h6>
    </div>
    <div class="card-body p-0">
      <?php if (empty($posts)): ?>
        <div class="p-3 text-center text-muted small">
          <?php echo Language::translate('COM_FREECHAT_NOT_FOUND'); ?>
        </div>
      <?php else: ?>
        <ul class="list-group list-group-flush">
          <?php foreach ($posts as $post): ?>
            <li class="list-group-item">
              <a href="index.php?option=freechat&view=topics&task=view&id=<?php echo $post->topic_id; ?>#post-<?php echo $post->id; ?>" class="text-decoration-none">
                <div class="small text-muted mb-1"><?php echo htmlspecialchars($post->topic_title); ?></div>
                <div class="post-excerpt"><?php echo htmlspecialchars(substr($post->content, 0, 100)) . (strlen($post->content) > 100 ? '...' : ''); ?></div>
                <small class="text-muted">
                  <?php echo htmlspecialchars($post->author_name); ?> -
                  <?php echo date('M d, H:i', strtotime($post->created_at)); ?>
                </small>
              </a>
            </li>
          <?php endforeach; ?>
        </ul>
      <?php endif; ?>
    </div>
  </div>
</div>
