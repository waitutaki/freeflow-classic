<?php
/**
 * Freechat Extension - Admin View - Moderation Queue
 */

defined('_FFEXEC') or die;
?>
<div class="container-fluid">
  <div class="row mb-3">
    <div class="col">
      <h1 class="h3 mb-0">
        <i class="fa-solid fa-gavel me-2"></i>
        <?php echo Language::translate('COM_FREECHAT_MODERATION_QUEUE'); ?>
      </h1>
    </div>
  </div>

  <div class="card">
    <div class="card-body">
      <?php if (empty($this->pendingPosts)): ?>
        <div class="alert alert-success">
          <i class="fa-solid fa-check-circle me-2"></i>
          <?php echo Language::translate('COM_FREECHAT_MODERATION_NO_PENDING'); ?>
        </div>
      <?php else: ?>
        <div class="list-group">
          <?php foreach ($this->pendingPosts as $post): ?>
            <div class="list-group-item">
              <div class="d-flex justify-content-between align-items-start">
                <div>
                  <h5 class="mb-1">
                    <a href="index.php?option=freechat&view=topics&task=view&id=<?php echo $post->topic_id; ?>#post-<?php echo $post->id; ?>">
                      <?php echo htmlspecialchars($post->topic_title); ?>
                    </a>
                  </h5>
                  <p class="mb-1">
                    <?php echo htmlspecialchars($post->content_html); ?>
                  </p>
                  <small class="text-muted">
                    <?php echo htmlspecialchars($post->author_name); ?> -
                    <?php echo date('Y-m-d H:i', strtotime($post->created_at)); ?> -
                    <?php echo htmlspecialchars($post->forum_title); ?>
                  </small>
                </div>
                <div>
                  <a href="index.php?option=freechat&view=moderation&task=approve&id=<?php echo $post->id; ?>" class="btn btn-sm btn-success" onclick="return confirm('Approve this post?')">
                    <i class="fa-solid fa-check me-1"></i>
                    <?php echo Language::translate('COM_FREECHAT_MODERATION_APPROVE'); ?>
                  </a>
                  <a href="index.php?option=freechat&view=moderation&task=reject&id=<?php echo $post->id; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Reject this post?')">
                    <i class="fa-solid fa-times me-1"></i>
                    <?php echo Language::translate('COM_FREECHAT_MODERATION_REJECT'); ?>
                  </a>
                </div>
              </div>
            </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>
