<?php
/**
 * Freechat Extension - Topics Controller
 * Site controller for viewing and creating topics
 */

namespace Freeflow\Extension\Freechat\Site;

defined('_FFEXEC') or die;

use Freeflow\Core\Controller;
use Freeflow\Core\Database;
use Freeflow\Core\Language;
use Freeflow\Core\User;
use Freeflow\Core\Application;

class TopicsController extends Controller
{
  /**
   * Display forum topics
   */
  public function display()
  {
    $forumId = $this->input->getInt('forum_id', 0);
    $forumSlug = $this->input->getString('forum_slug', '');
    
    if (!$forumId && empty($forumSlug)) {
      Application::redirect('index.php?option=freechat');
    }
    
    $db = Database::getInstance();
    
    // Get forum details
    if ($forumId) {
      $forum = $db->getQuery(true)
        ->select('f.*, c.title as category_title, c.slug as category_slug, s.title as space_title, s.slug as space_slug')
        ->from('#_ext_freechat_forums f')
        ->leftJoin('#_ext_freechat_categories c ON f.category_id = c.id')
        ->leftJoin('#_ext_freechat_spaces s ON c.space_id = s.id')
        ->where('f.id = ' . $forumId)
        ->loadObject();
    } else {
      $forum = $db->getQuery(true)
        ->select('f.*, c.title as category_title, c.slug as category_slug, s.title as space_title, s.slug as space_slug')
        ->from('#_ext_freechat_forums f')
        ->leftJoin('#_ext_freechat_categories c ON f.category_id = c.id')
        ->leftJoin('#_ext_freechat_spaces s ON c.space_id = s.id')
        ->where('f.slug = ' . $db->quote($forumSlug))
        ->loadObject();
    }
    
    if (!$forum || $forum->state != 1) {
      Application::enqueueMessage(Language::translate('COM_FREECHAT_NOT_FOUND'), 'error');
      Application::redirect('index.php?option=freechat');
    }
    
    // Check permissions
    $user = User::getInstance();
    $canView = $user->can('freechat.topics.view');
    
    if (!$canView) {
      Application::enqueueMessage(Language::translate('COM_FREECHAT_ERROR_PERMISSION_DENIED'), 'error');
      Application::redirect('index.php?option=freechat');
    }
    
    // Get topics
    $query = $db->getQuery(true)
      ->select('t.*')
      ->select('u.name as author_name')
      ->select('(SELECT COUNT(*) FROM #_ext_freechat_posts WHERE topic_id = t.id AND state = \'published\') as post_count')
      ->from('#_ext_freechat_topics t')
      ->leftJoin('#_users u ON t.created_by = u.id')
      ->where('t.forum_id = ' . $forum->id)
      ->where('t.state IN (\'open\',\'locked\')');
    
    // Pagination
    $limit = 20;
    $page = $this->input->getInt('page', 1);
    $offset = ($page - 1) * $limit;
    
    $total = $db->setQuery($query)->getNumRows();
    
    $query->order('t.type DESC, t.last_post_at DESC')
      ->setLimit($limit, $offset);
    
    $topics = $db->setQuery($query)->loadObjectList();
    
    $this->view->assign('forum', $forum);
    $this->view->assign('topics', $topics);
    $this->view->assign('pagination', [
      'total' => $total,
      'limit' => $limit,
      'page' => $page,
      'pages' => ceil($total / $limit)
    ]);
    $this->view->setLayout('default');
    $this->view->display();
  }
  
  /**
   * View single topic
   */
  public function view()
  {
    $topicId = $this->input->getInt('id', 0);
    $topicSlug = $this->input->getString('slug', '');
    
    if (!$topicId && empty($topicSlug)) {
      Application::redirect('index.php?option=freechat');
    }
    
    $db = Database::getInstance();
    
    // Get topic
    if ($topicId) {
      $topic = $db->getQuery(true)
        ->select('t.*')
        ->select('f.title as forum_title, f.id as forum_id, f.slug as forum_slug')
        ->select('u.name as author_name')
        ->from('#_ext_freechat_topics t')
        ->leftJoin('#_ext_freechat_forums f ON t.forum_id = f.id')
        ->leftJoin('#_users u ON t.created_by = u.id')
        ->where('t.id = ' . $topicId)
        ->loadObject();
    } else {
      $topic = $db->getQuery(true)
        ->select('t.*')
        ->select('f.title as forum_title, f.id as forum_id, f.slug as forum_slug')
        ->select('u.name as author_name')
        ->from('#_ext_freechat_topics t')
        ->leftJoin('#_ext_freechat_forums f ON t.forum_id = f.id')
        ->leftJoin('#_users u ON t.created_by = u.id')
        ->where('t.slug = ' . $db->quote($topicSlug))
        ->loadObject();
    }
    
    if (!$topic) {
      Application::enqueueMessage(Language::translate('COM_FREECHAT_TOPIC_NOT_FOUND'), 'error');
      Application::redirect('index.php?option=freechat');
    }
    
    // Check if private topic
    if ($topic->is_private) {
      $user = User::getInstance();
      if (!$user->id || ($user->id != $topic->created_by && !$user->can('freechat.moderate'))) {
        Application::enqueueMessage(Language::translate('COM_FREECHAT_ERROR_TOPIC_PRIVATE'), 'error');
        Application::redirect('index.php?option=freechat');
      }
    }
    
    // Increment view count
    $db->update('#_ext_freechat_topics', ['view_count' => $topic->view_count + 1], ['id' => $topic->id]);
    
    // Get posts
    $query = $db->getQuery(true)
      ->select('p.*')
      ->select('u.name as author_name, u.avatar')
      ->from('#_ext_freechat_posts p')
      ->leftJoin('#_users u ON p.author_id = u.id')
      ->where('p.topic_id = ' . $topic->id)
      ->where('p.state = ' . $db->quote('published'));
    
    // Pagination for posts
    $limit = 10;
    $page = $this->input->getInt('page', 1);
    $offset = ($page - 1) * $limit;
    
    $total = $db->setQuery($query)->getNumRows();
    
    $query->order('p.created_at ASC')
      ->setLimit($limit, $offset);
    
    $posts = $db->setQuery($query)->loadObjectList();
    
    // Get reactions for posts
    foreach ($posts as &$post) {
      $post->reactions = $db->getQuery(true)
        ->select('type, COUNT(*) as count')
        ->from('#_ext_freechat_reactions')
        ->where('post_id = ' . $post->id)
        ->group('type')
        ->loadObjectList();
    }
    
    // Check if user has reacted
    $user = User::getInstance();
    if ($user->id) {
      foreach ($posts as &$post) {
        $userReaction = $db->getQuery(true)
          ->select('type')
          ->from('#_ext_freechat_reactions')
          ->where('post_id = ' . $post->id)
          ->where('user_id = ' . $user->id)
          ->loadResult();
        
        $post->user_reaction = $userReaction;
      }
      
      // Check subscription
      $topic->is_subscribed = $db->getQuery(true)
        ->select('COUNT(*)')
        ->from('#_ext_freechat_subscriptions')
        ->where('user_id = ' . $user->id)
        ->where('type = ' . $db->quote('topic'))
        ->where('item_id = ' . $topic->id)
        ->loadResult() > 0;
    }
    
    $this->view->assign('topic', $topic);
    $this->view->assign('posts', $posts);
    $this->view->assign('pagination', [
      'total' => $total,
      'limit' => $limit,
      'page' => $page,
      'pages' => ceil($total / $limit)
    ]);
    $this->view->setLayout('view');
    $this->view->display();
  }
  
  /**
   * Create new topic form
   */
  public function create()
  {
    $user = User::getInstance();
    
    if (!$user->id) {
      Application::redirect('index.php?option=users&view=login&return=' . urlencode(Application::getUri()));
    }
    
    if (!$user->can('freechat.topics.create')) {
      Application::enqueueMessage(Language::translate('COM_FREECHAT_ERROR_PERMISSION_DENIED'), 'error');
      Application::redirect('index.php?option=freechat');
    }
    
    $forumId = $this->input->getInt('forum_id', 0);
    
    $db = Database::getInstance();
    
    $forums = $db->getQuery(true)
      ->select('f.*, c.title as category_title, s.title as space_title')
      ->from('#_ext_freechat_forums f')
      ->leftJoin('#_ext_freechat_categories c ON f.category_id = c.id')
      ->leftJoin('#_ext_freechat_spaces s ON c.space_id = s.id')
      ->where('f.state = 1')
      ->order('s.title ASC, c.title ASC, f.title ASC')
      ->loadObjectList();
    
    $this->view->assign('forums', $forums);
    $this->view->assign('selectedForumId', $forumId);
    $this->view->setLayout('create');
    $this->view->display();
  }
  
  /**
   * Save new topic
   */
  public function save()
  {
    $user = User::getInstance();
    
    if (!$user->id) {
      Application::enqueueMessage(Language::translate('COM_FREECHAT_PLEASE_LOGIN'), 'error');
      Application::redirect('index.php?option=users&view=login');
    }
    
    if (!$user->can('freechat.topics.create')) {
      Application::enqueueMessage(Language::translate('COM_FREECHAT_ERROR_PERMISSION_DENIED'), 'error');
      Application::redirect('index.php?option=freechat');
    }
    
    $forumId = $this->input->getInt('forum_id', 0);
    $title = $this->input->getString('title', '');
    $content = $this->input->getRaw('content', '');
    $isPrivate = $this->input->getInt('is_private', 0);
    
    if (!$forumId || empty($title) || empty($content)) {
      Application::enqueueMessage(Language::translate('COM_FREECHAT_ERROR_INVALID_INPUT'), 'error');
      Application::redirect('index.php?option=freechat&view=topics&task=create&forum_id=' . $forumId);
    }
    
    // Get forum to check moderation model
    $db = Database::getInstance();
    
    $forum = $db->getQuery(true)
      ->select('f.*, c.moderation_model as cat_moderation')
      ->from('#_ext_freechat_forums f')
      ->leftJoin('#_ext_freechat_categories c ON f.category_id = c.id')
      ->where('f.id = ' . $forumId)
      ->loadObject();
    
    if (!$forum) {
      Application::enqueueMessage(Language::translate('COM_FREECHAT_NOT_FOUND'), 'error');
      Application::redirect('index.php?option=freechat');
    }
    
    // Determine moderation state
    $moderationModel = $forum->override_category_settings ? $forum->moderation_model : $forum->cat_moderation;
    $postState = ($moderationModel == 'premod') ? 'hidden' : 'published';
    
    $now = date('Y-m-d H:i:s');
    $ipAddress = $_SERVER['REMOTE_ADDR'] ?? '';
    
    // Create topic
    $topicData = [
      'forum_id' => $forumId,
      'title' => $title,
      'slug' => $this->generateSlug($title),
      'type' => 'normal',
      'state' => 'open',
      'is_private' => $isPrivate,
      'view_count' => 0,
      'reply_count' => 0,
      'created_at' => $now,
      'created_by' => $user->id
    ];
    
    $result = $db->insert('#_ext_freechat_topics', $topicData);
    $topicId = $db->insertid();
    
    if (!$result) {
      Application::enqueueMessage(Language::translate('COM_FREECHAT_ERROR'), 'error');
      Application::redirect('index.php?option=freechat&view=topics&task=create&forum_id=' . $forumId);
    }
    
    // Create first post
    $postData = [
      'topic_id' => $topicId,
      'parent_id' => 0,
      'author_id' => $user->id,
      'content' => $content,
      'content_html' => $this->processContent($content),
      'state' => $postState,
      'is_first_post' => 1,
      'created_at' => $now,
      'ip_address' => $ipAddress
    ];
    
    $db->insert('#_ext_freechat_posts', $postData);
    $postId = $db->insertid();
    
    // Update topic with first post ID
    $db->update('#_ext_freechat_topics', ['first_post_id' => $postId], ['id' => $topicId]);
    
    // Update topic last post info
    $db->update('#_ext_freechat_topics', [
      'last_post_id' => $postId,
      'last_post_at' => $now,
      'last_post_by' => $user->id
    ], ['id' => $topicId]);
    
    // Auto-subscribe topic creator
    $db->insert('#_ext_freechat_subscriptions', [
      'user_id' => $user->id,
      'type' => 'topic',
      'item_id' => $topicId,
      'notify_on' => 'reply,mention,quote',
      'email_digest' => 'none',
      'created_at' => $now
    ]);
    
    Application::enqueueMessage(Language::translate('COM_FREECHAT_TOPIC_SAVED'), 'success');
    Application::redirect('index.php?option=freechat&view=topics&task=view&id=' . $topicId);
  }
  
  /**
   * Toggle subscription
   */
  public function toggleSubscription()
  {
    $user = User::getInstance();
    
    if (!$user->id) {
      echo json_encode(['success' => false, 'message' => 'Please login']);
      return;
    }
    
    $topicId = $this->input->getInt('topic_id', 0);
    
    if (!$topicId) {
      echo json_encode(['success' => false, 'message' => 'Invalid topic']);
      return;
    }
    
    $db = Database::getInstance();
    
    $exists = $db->getQuery(true)
      ->select('COUNT(*)')
      ->from('#_ext_freechat_subscriptions')
      ->where('user_id = ' . $user->id)
      ->where('type = ' . $db->quote('topic'))
      ->where('item_id = ' . $topicId)
      ->loadResult();
    
    if ($exists) {
      $db->delete('#_ext_freechat_subscriptions', [
        'user_id' => $user->id,
        'type' => 'topic',
        'item_id' => $topicId
      ]);
      echo json_encode(['success' => true, 'subscribed' => false]);
    } else {
      $db->insert('#_ext_freechat_subscriptions', [
        'user_id' => $user->id,
        'type' => 'topic',
        'item_id' => $topicId,
        'notify_on' => 'reply,mention,quote',
        'email_digest' => 'none',
        'created_at' => date('Y-m-d H:i:s')
      ]);
      echo json_encode(['success' => true, 'subscribed' => true]);
    }
  }
  
  private function generateSlug($title)
  {
    $slug = strtolower(trim($title));
    $slug = preg_replace('/[^a-z0-9-]/', '-', $slug);
    $slug = preg_replace('/-+/', '-', $slug);
    $slug = trim($slug, '-');
    
    $db = Database::getInstance();
    $i = 1;
    $originalSlug = $slug;
    
    while (true) {
      $exists = $db->getQuery(true)
        ->select('COUNT(*)')
        ->from('#_ext_freechat_topics')
        ->where('slug = ' . $db->quote($slug))
        ->loadResult();
      
      if (!$exists) {
        break;
      }
      
      $slug = $originalSlug . '-' . $i++;
    }
    
    return $slug;
  }
  
  private function processContent($content)
  {
    // Basic content processing - in production would use Freewrite API
    $html = htmlspecialchars($content);
    $html = nl2br($html);
    return $html;
  }
}
