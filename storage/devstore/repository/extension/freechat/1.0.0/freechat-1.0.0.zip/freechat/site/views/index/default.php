<?php
/**
 * Freechat Extension - Site View - Forum Index
 */

defined('_FFEXEC') or die;
?>
<div class="freechat-container">
  <div class="row mb-4">
    <div class="col">
      <h1 class="h3 mb-0">
        <i class="fa-solid fa-comments me-2"></i>
        <?php echo Language::translate('COM_FREECHAT_FORUM_INDEX'); ?>
      </h1>
    </div>
  </div>

  <?php if (empty($this->spaces)): ?>
    <div class="alert alert-info">
      <?php echo Language::translate('COM_FREECHAT_NOT_FOUND'); ?>
    </div>
  <?php else: ?>
    <?php foreach ($this->spaces as $space): ?>
      <div class="card mb-4">
        <div class="card-header bg-primary text-white">
          <h5 class="mb-0">
            <i class="fa-solid fa-layer-group me-2"></i>
            <?php echo htmlspecialchars($space->title); ?>
          </h5>
          <?php if ($space->description): ?>
            <small><?php echo htmlspecialchars($space->description); ?></small>
          <?php endif; ?>
        </div>
        <div class="card-body p-0">
          <?php foreach ($space->categories as $category): ?>
            <div class="p-3 border-bottom">
              <h6 class="mb-2">
                <i class="fa-solid fa-folder me-1"></i>
                <?php echo htmlspecialchars($category->title); ?>
              </h6>
              
              <?php if (empty($category->forums)): ?>
                <p class="text-muted mb-0 small"><?php echo Language::translate('COM_FREECHAT_FORUM_NO_FORUMS'); ?></p>
              <?php else: ?>
                <div class="row">
                  <?php foreach ($category->forums as $forum): ?>
                    <div class="col-md-6 mb-2">
                      <div class="forum-item p-2 rounded">
                        <a href="index.php?option=freechat&view=topics&forum_id=<?php echo $forum->id; ?>" class="text-decoration-none">
                          <strong><?php echo htmlspecialchars($forum->title); ?></strong>
                        </a>
                        <?php if ($forum->description): ?>
                          <p class="small text-muted mb-1"><?php echo htmlspecialchars($forum->description); ?></p>
                        <?php endif; ?>
                        <div class="small text-muted">
                          <span class="me-3">
                            <i class="fa-regular fa-comment me-1"></i>
                            <?php echo $topic_count = $forum->topic_count ?? 0; ?> <?php echo Language::translate('COM_FREECHAT_TOPICS'); ?>
                          </span>
                          <span class="me-3">
                            <i class="fa-regular fa-comments me-1"></i>
                            <?php echo $post_count = $forum->post_count ?? 0; ?> <?php echo Language::translate('COM_FREECHAT_POSTS'); ?>
                          </span>
                        </div>
                      </div>
                    </div>
                  <?php endforeach; ?>
                </div>
              <?php endif; ?>
            </div>
          <?php endforeach; ?>
        </div>
      </div>
    <?php endforeach; ?>
  <?php endif; ?>
</div>
