<?php
/**
 * Freechat Extension - Moderation Controller
 * Admin controller for moderation queue and actions
 */

namespace Freeflow\Extension\Freechat\Admin;

defined('_FFEXEC') or die;

use Freeflow\Core\Controller;
use Freeflow\Core\Database;
use Freeflow\Core\Language;
use Freeflow\Core\User;
use Freeflow\Core\Application;

class ModerationController extends Controller
{
  /**
   * Display moderation queue
   */
  public function display()
  {
    $this->checkPermission('freechat.moderate');
    
    $db = Database::getInstance();
    
    // Get posts pending moderation (from postmod categories/forums)
    $query = $db->getQuery(true)
      ->select('p.*, t.title as topic_title, f.title as forum_title, u.name as author_name')
      ->from('#_ext_freechat_posts p')
      ->leftJoin('#_ext_freechat_topics t ON p.topic_id = t.id')
      ->leftJoin('#_ext_freechat_forums f ON t.forum_id = f.id')
      ->leftJoin('#_users u ON p.author_id = u.id')
      ->where('p.state = ' . $db->quote('hidden'))
      ->where('p.created_at > DATE_SUB(NOW(), INTERVAL 30 DAY)')
      ->order('p.created_at DESC');
    
    $pendingPosts = $db->setQuery($query)->loadObjectList();
    
    $this->view->assign('pendingPosts', $pendingPosts);
    $this->view->setLayout('default');
    $this->view->display();
  }
  
  /**
   * Approve post
   */
  public function approve()
  {
    $this->checkPermission('freechat.moderate');
    
    $id = $this->input->getInt('id', 0);
    
    if (!$id) {
      Application::enqueueMessage(Language::translate('COM_FREECHAT_NOT_FOUND'), 'error');
      $this->redirect('index.php?option=freechat&view=moderation');
    }
    
    $db = Database::getInstance();
    
    $result = $db->update('#_ext_freechat_posts',
      ['state' => 'published'],
      ['id' => $id]
    );
    
    if ($result === false) {
      Application::enqueueMessage(Language::translate('COM_FREECHAT_ERROR'), 'error');
    } else {
      Application::enqueueMessage(Language::translate('COM_FREECHAT_SUCCESS'), 'success');
    }
    
    $this->redirect('index.php?option=freechat&view=moderation');
  }
  
  /**
   * Reject post (soft delete)
   */
  public function reject()
  {
    $this->checkPermission('freechat.moderate');
    
    $id = $this->input->getInt('id', 0);
    $reason = $this->input->getString('reason', '');
    
    if (!$id) {
      Application::enqueueMessage(Language::translate('COM_FREECHAT_NOT_FOUND'), 'error');
      $this->redirect('index.php?option=freechat&view=moderation');
    }
    
    $db = Database::getInstance();
    
    $result = $db->update('#_ext_freechat_posts',
      ['state' => 'soft_deleted'],
      ['id' => $id]
    );
    
    if ($result === false) {
      Application::enqueueMessage(Language::translate('COM_FREECHAT_ERROR'), 'error');
    } else {
      Application::enqueueMessage(Language::translate('COM_FREECHAT_SUCCESS'), 'success');
    }
    
    $this->redirect('index.php?option=freechat&view=moderation');
  }
  
  /**
   * Lock topic
   */
  public function lockTopic()
  {
    $this->checkPermission('freechat.moderate');
    
    $id = $this->input->getInt('id', 0);
    
    if (!$id) {
      echo json_encode(['success' => false]);
      return;
    }
    
    $db = Database::getInstance();
    
    $result = $db->update('#_ext_freechat_topics',
      ['state' => 'locked', 'modified_at' => date('Y-m-d H:i:s')],
      ['id' => $id]
    );
    
    echo json_encode(['success' => $result !== false]);
  }
  
  /**
   * Unlock topic
   */
  public function unlockTopic()
  {
    $this->checkPermission('freechat.moderate');
    
    $id = $this->input->getInt('id', 0);
    
    if (!$id) {
      echo json_encode(['success' => false]);
      return;
    }
    
    $db = Database::getInstance();
    
    $result = $db->update('#_ext_freechat_topics',
      ['state' => 'open', 'modified_at' => date('Y-m-d H:i:s')],
      ['id' => $id]
    );
    
    echo json_encode(['success' => $result !== false]);
  }
  
  /**
   * Make topic sticky
   */
  public function stickyTopic()
  {
    $this->checkPermission('freechat.moderate');
    
    $id = $this->input->getInt('id', 0);
    
    if (!$id) {
      echo json_encode(['success' => false]);
      return;
    }
    
    $db = Database::getInstance();
    
    $result = $db->update('#_ext_freechat_topics',
      ['type' => 'sticky', 'modified_at' => date('Y-m-d H:i:s')],
      ['id' => $id]
    );
    
    echo json_encode(['success' => $result !== false]);
  }
  
  /**
   * Remove sticky status
   */
  public function unstickyTopic()
  {
    $this->checkPermission('freechat.moderate');
    
    $id = $this->input->getInt('id', 0);
    
    if (!$id) {
      echo json_encode(['success' => false]);
      return;
    }
    
    $db = Database::getInstance();
    
    $result = $db->update('#_ext_freechat_topics',
      ['type' => 'normal', 'modified_at' => date('Y-m-d H:i:s')],
      ['id' => $id]
    );
    
    echo json_encode(['success' => $result !== false]);
  }
  
  /**
   * Move topic to different forum
   */
  public function moveTopic()
  {
    $this->checkPermission('freechat.moderate');
    
    $id = $this->input->getInt('id', 0);
    $targetForumId = $this->input->getInt('target_forum_id', 0);
    
    if (!$id || !$targetForumId) {
      echo json_encode(['success' => false, 'message' => 'Invalid parameters']);
      return;
    }
    
    $db = Database::getInstance();
    
    $result = $db->update('#_ext_freechat_topics',
      ['forum_id' => $targetForumId, 'modified_at' => date('Y-m-d H:i:s')],
      ['id' => $id]
    );
    
    if ($result !== false) {
      echo json_encode(['success' => true]);
    } else {
      echo json_encode(['success' => false, 'message' => 'Database error']);
    }
  }
  
  /**
   * Merge topics
   */
  public function mergeTopics()
  {
    $this->checkPermission('freechat.moderate');
    
    $sourceId = $this->input->getInt('source_id', 0);
    $targetId = $this->input->getInt('target_id', 0);
    
    if (!$sourceId || !$targetId || $sourceId === $targetId) {
      echo json_encode(['success' => false, 'message' => 'Invalid parameters']);
      return;
    }
    
    $db = Database::getInstance();
    
    // Move posts from source to target
    $db->update('#_ext_freechat_posts',
      ['topic_id' => $targetId],
      ['topic_id' => $sourceId]
    );
    
    // Delete source topic
    $result = $db->delete('#_ext_freechat_topics', ['id' => $sourceId]);
    
    if ($result !== false) {
      // Update target topic post count
      $postCount = $db->getQuery(true)
        ->select('COUNT(*)')
        ->from('#_ext_freechat_posts')
        ->where('topic_id = ' . $targetId)
        ->where('state = ' . $db->quote('published'))
        ->loadResult();
      
      $db->update('#_ext_freechat_topics',
        [
          'reply_count' => $postCount - 1,
          'modified_at' => date('Y-m-d H:i:s')
        ],
        ['id' => $targetId]
      );
      
      echo json_encode(['success' => true]);
    } else {
      echo json_encode(['success' => false, 'message' => 'Database error']);
    }
  }
}
