<?php
/**
 * Freechat Extension - Categories Controller
 * Admin controller for managing forum categories
 */

namespace Freeflow\Extension\Freechat\Admin;

defined('_FFEXEC') or die;

use Freeflow\Core\Controller;
use Freeflow\Core\Database;
use Freeflow\Core\Language;
use Freeflow\Core\User;
use Freeflow\Core\Application;

class CategoriesController extends Controller
{
  /**
   * Display list of categories
   */
  public function display()
  {
    $this->checkPermission('freechat.categories.manage');
    
    $db = Database::getInstance();
    
    $query = $db->getQuery(true)
      ->select('c.*, s.title as space_title')
      ->from('#_ext_freechat_categories c')
      ->leftJoin('#_ext_freechat_spaces s ON c.space_id = s.id')
      ->order('c.ordering ASC');
    
    $categories = $db->setQuery($query)->loadObjectList();
    
    // Get spaces for dropdown
    $spaces = $db->getQuery(true)
      ->select('id, title')
      ->from('#_ext_freechat_spaces')
      ->where('state = 1')
      ->order('ordering ASC')
      ->loadObjectList();
    
    $this->view->assign('categories', $categories);
    $this->view->assign('spaces', $spaces);
    $this->view->setLayout('default');
    $this->view->display();
  }
  
  /**
   * New category form
   */
  public function add()
  {
    $this->checkPermission('freechat.categories.manage');
    
    $db = Database::getInstance();
    
    $spaces = $db->getQuery(true)
      ->select('id, title')
      ->from('#_ext_freechat_spaces')
      ->where('state = 1')
      ->order('ordering ASC')
      ->loadObjectList();
    
    $this->view->assign('spaces', $spaces);
    $this->view->setLayout('edit');
    $this->view->display();
  }
  
  /**
   * Edit category form
   */
  public function edit()
  {
    $this->checkPermission('freechat.categories.manage');
    
    $id = $this->input->getInt('id', 0);
    
    if (!$id) {
      Application::enqueueMessage(Language::translate('COM_FREECHAT_NOT_FOUND'), 'error');
      $this->redirect('index.php?option=freechat&view=categories');
    }
    
    $db = Database::getInstance();
    
    $category = $db->getQuery(true)
      ->select('*')
      ->from('#_ext_freechat_categories')
      ->where('id = ' . $id)
      ->loadObject();
    
    if (!$category) {
      Application::enqueueMessage(Language::translate('COM_FREECHAT_NOT_FOUND'), 'error');
      $this->redirect('index.php?option=freechat&view=categories');
    }
    
    $spaces = $db->getQuery(true)
      ->select('id, title')
      ->from('#_ext_freechat_spaces')
      ->where('state = 1')
      ->order('ordering ASC')
      ->loadObjectList();
    
    $this->view->assign('category', $category);
    $this->view->assign('spaces', $spaces);
    $this->view->setLayout('edit');
    $this->view->display();
  }
  
  /**
   * Save category
   */
  public function save()
  {
    $this->checkPermission('freechat.categories.manage');
    
    $id = $this->input->getInt('id', 0);
    $spaceId = $this->input->getInt('space_id', 0);
    $parentId = $this->input->getInt('parent_id', 0);
    $title = $this->input->getString('title', '');
    $description = $this->input->getRaw('description', '');
    $threadingDepth = $this->input->getInt('threading_depth', 3);
    $moderationModel = $this->input->getString('moderation_model', 'open');
    $allowTags = $this->input->getInt('allow_tags', 1);
    $allowRevisions = $this->input->getInt('allow_revisions', 1);
    $ordering = $this->input->getInt('ordering', 0);
    $state = $this->input->getInt('state', 1);
    
    if (empty($title) || !$spaceId) {
      Application::enqueueMessage(Language::translate('COM_FREECHAT_ERROR_INVALID_INPUT'), 'error');
      $redirectUrl = $id ? 'index.php?option=freechat&view=categories&task=edit&id=' . $id : 'index.php?option=freechat&view=categories&task=add';
      $this->redirect($redirectUrl);
    }
    
    $db = Database::getInstance();
    $user = User::getInstance();
    $now = date('Y-m-d H:i:s');
    
    $data = [
      'space_id' => $spaceId,
      'parent_id' => $parentId,
      'title' => $title,
      'slug' => $this->generateSlug($title),
      'description' => $description,
      'threading_depth' => $threadingDepth,
      'moderation_model' => $moderationModel,
      'allow_tags' => $allowTags,
      'allow_revisions' => $allowRevisions,
      'ordering' => $ordering,
      'state' => $state,
      'modified_at' => $now,
      'modified_by' => $user->id
    ];
    
    if ($id) {
      $data['id'] = $id;
      $result = $db->update('#_ext_freechat_categories', $data, 'id');
    } else {
      $data['created_at'] = $now;
      $data['created_by'] = $user->id;
      $result = $db->insert('#_ext_freechat_categories', $data);
      $id = $db->insertid();
    }
    
    if ($result === false) {
      Application::enqueueMessage(Language::translate('COM_FREECHAT_ERROR'), 'error');
    } else {
      Application::enqueueMessage(Language::translate('COM_FREECHAT_CATEGORY_SAVED'), 'success');
    }
    
    $this->redirect('index.php?option=freechat&view=categories');
  }
  
  /**
   * Delete category
   */
  public function delete()
  {
    $this->checkPermission('freechat.categories.manage');
    
    $id = $this->input->getInt('id', 0);
    
    if (!$id) {
      Application::enqueueMessage(Language::translate('COM_FREECHAT_NOT_FOUND'), 'error');
      $this->redirect('index.php?option=freechat&view=categories');
    }
    
    $db = Database::getInstance();
    
    // Check if category has forums
    $count = $db->getQuery(true)
      ->select('COUNT(*)')
      ->from('#_ext_freechat_forums')
      ->where('category_id = ' . $id)
      ->loadResult();
    
    if ($count > 0) {
      Application::enqueueMessage('Cannot delete category with forums. Delete forums first.', 'error');
      $this->redirect('index.php?option=freechat&view=categories');
    }
    
    $result = $db->delete('#_ext_freechat_categories', ['id' => $id]);
    
    if ($result === false) {
      Application::enqueueMessage(Language::translate('COM_FREECHAT_ERROR'), 'error');
    } else {
      Application::enqueueMessage(Language::translate('COM_FREECHAT_CATEGORY_DELETED'), 'success');
    }
    
    $this->redirect('index.php?option=freechat&view=categories');
  }
  
  /**
   * Toggle state
   */
  public function toggleState()
  {
    $this->checkPermission('freechat.categories.manage');
    
    $id = $this->input->getInt('id', 0);
    $newState = $this->input->getInt('state', 0);
    
    if (!$id) {
      echo json_encode(['success' => false, 'message' => 'Invalid ID']);
      return;
    }
    
    $db = Database::getInstance();
    
    $result = $db->update('#_ext_freechat_categories',
      ['state' => $newState, 'modified_at' => date('Y-m-d H:i:s')],
      ['id' => $id]
    );
    
    echo json_encode([
      'success' => $result !== false,
      'newState' => $newState,
      'icon' => $newState ? 'fa-circle-check text-success' : 'fa-circle-xmark text-danger'
    ]);
  }
  
  /**
   * Get categories by space for AJAX
   */
  public function getBySpace()
  {
    $spaceId = $this->input->getInt('space_id', 0);
    
    $db = Database::getInstance();
    
    $categories = $db->getQuery(true)
      ->select('id, title')
      ->from('#_ext_freechat_categories')
      ->where('space_id = ' . $spaceId)
      ->where('state = 1')
      ->order('ordering ASC')
      ->loadObjectList();
    
    echo json_encode(['categories' => $categories]);
  }
  
  private function generateSlug($title)
  {
    $slug = strtolower(trim($title));
    $slug = preg_replace('/[^a-z0-9-]/', '-', $slug);
    $slug = preg_replace('/-+/', '-', $slug);
    $slug = trim($slug, '-');
    
    $db = Database::getInstance();
    $i = 1;
    $originalSlug = $slug;
    
    while (true) {
      $exists = $db->getQuery(true)
        ->select('COUNT(*)')
        ->from('#_ext_freechat_categories')
        ->where('slug = ' . $db->quote($slug))
        ->loadResult();
      
      if (!$exists) {
        break;
      }
      
      $slug = $originalSlug . '-' . $i++;
    }
    
    return $slug;
  }
}
