/**
 * Freechat Extension - JavaScript
 * Version: 1.0.0
 */

(function() {
  'use strict';

  // Freechat namespace
  window.freechat = window.freechat || {};

  /**
   * Toggle state (publish/unpublish)
   */
  freechat.toggleState = function(btn) {
    var id = btn.dataset.id;
    var newState = parseInt(btn.dataset.state) ? 0 : 1;
    var url = btn.dataset.url + '&id=' + id + '&state=' + newState;

    fetch(url)
      .then(function(response) { return response.json(); })
      .then(function(data) {
        if (data.success) {
          var icon = btn.querySelector('i');
          icon.className = 'fa-solid ' + data.icon + ' fa-lg';
          btn.dataset.state = newState;
        }
      })
      .catch(function(error) {
        console.error('Toggle failed:', error);
      });
  };

  /**
   * Toggle sticky status
   */
  freechat.toggleSticky = function(btn) {
    var id = btn.dataset.id;
    var isSticky = parseInt(btn.dataset.sticky);
    var newSticky = isSticky ? 0 : 1;
    var url = btn.dataset.url + '&id=' + id + '&sticky=' + newSticky;

    fetch(url)
      .then(function(response) { return response.json(); })
      .then(function(data) {
        if (data.success) {
          var icon = btn.querySelector('i');
          icon.className = 'fa-solid ' + (newSticky ? 'fa-thumbtack text-warning' : 'fa-regular fa-thumbtack') + ' fa-lg';
          btn.dataset.sticky = newSticky;
        }
      })
      .catch(function(error) {
        console.error('Toggle sticky failed:', error);
      });
  };

  /**
   * Toggle locked status
   */
  freechat.toggleLocked = function(btn) {
    var id = btn.dataset.id;
    var isLocked = parseInt(btn.dataset.locked);
    var newLocked = isLocked ? 0 : 1;
    var url = btn.dataset.url + '&id=' + id + '&locked=' + newLocked;

    fetch(url)
      .then(function(response) { return response.json(); })
      .then(function(data) {
        if (data.success) {
          var icon = btn.querySelector('i');
          icon.className = 'fa-solid ' + (newLocked ? 'fa-lock text-danger' : 'fa-lock-open text-success') + ' fa-lg';
          btn.dataset.locked = newLocked;
        }
      })
      .catch(function(error) {
        console.error('Toggle locked failed:', error);
      });
  };

  /**
   * Toggle subscription
   */
  freechat.toggleSubscription = function(btn) {
    var topicId = btn.dataset.topicId;
    var url = 'index.php?option=freechat&view=topics&task=toggleSubscription&topic_id=' + topicId;

    fetch(url)
      .then(function(response) { return response.json(); })
      .then(function(data) {
        if (data.success) {
          var icon = btn.querySelector('i');
          if (data.subscribed) {
            btn.classList.remove('btn-outline-warning');
            btn.classList.add('btn-warning');
            icon.classList.remove('fa-regular');
            icon.classList.add('fa-solid');
            btn.childNodes[2].textContent = ' ' + btn.dataset.subscribedText || 'Subscribed';
          } else {
            btn.classList.remove('btn-warning');
            btn.classList.add('btn-outline-warning');
            icon.classList.remove('fa-solid');
            icon.classList.add('fa-regular');
            btn.childNodes[2].textContent = ' ' + btn.dataset.unsubscribedText || 'Not Subscribed';
          }
        }
      })
      .catch(function(error) {
        console.error('Toggle subscription failed:', error);
      });
  };

  /**
   * Add reaction
   */
  freechat.addReaction = function(btn) {
    var postId = btn.dataset.postId;
    var type = btn.dataset.type;
    var url = 'index.php?option=freechat&view=posts&task=react&post_id=' + postId + '&type=' + type;

    fetch(url)
      .then(function(response) { return response.json(); })
      .then(function(data) {
        if (data.success) {
          // Update button state
          btn.classList.add('active');
          
          // Could update reaction counts here
        }
      })
      .catch(function(error) {
        console.error('Add reaction failed:', error);
      });
  };

  /**
   * Report post
   */
  freechat.showReportModal = function(postId) {
    var modal = document.getElementById('reportModal');
    if (modal) {
      modal.dataset.postId = postId;
      var modalInstance = new bootstrap.Modal(modal);
      modalInstance.show();
    }
  };

  /**
   * Submit report
   */
  freechat.submitReport = function(form) {
    var postId = form.dataset.postId;
    var reason = form.querySelector('[name="reason"]').value;
    var details = form.querySelector('[name="details"]').value;
    
    var url = 'index.php?option=freechat&view=posts&task=report&post_id=' + postId;
    
    var params = new URLSearchParams();
    params.append('reason', reason);
    params.append('details', details);
    
    fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      body: params.toString()
    })
      .then(function(response) { return response.url; })
      .then(function(url) {
        window.location.href = url;
      })
      .catch(function(error) {
        console.error('Submit report failed:', error);
      });
  };

  /**
   * Delete post
   */
  freechat.deletePost = function(btn) {
    if (!confirm('Are you sure you want to delete this post?')) {
      return;
    }
    
    var postId = btn.dataset.postId;
    var url = 'index.php?option=freechat&view=posts&task=delete&id=' + postId;

    fetch(url)
      .then(function(response) { return response.json(); })
      .then(function(data) {
        if (data.success) {
          var postItem = document.getElementById('post-' + postId);
          if (postItem) {
            postItem.style.opacity = '0.5';
            postItem.querySelector('.post-content').textContent = 'This post has been deleted';
          }
        }
      })
      .catch(function(error) {
        console.error('Delete post failed:', error);
      });
  };

  /**
   * Initialize on DOM ready
   */
  document.addEventListener('DOMContentLoaded', function() {
    // Toggle state buttons
    document.querySelectorAll('.toggle-state').forEach(function(btn) {
      btn.addEventListener('click', function(e) {
        e.preventDefault();
        freechat.toggleState(this);
      });
    });

    // Toggle sticky buttons
    document.querySelectorAll('.toggle-sticky').forEach(function(btn) {
      btn.addEventListener('click', function(e) {
        e.preventDefault();
        freechat.toggleSticky(this);
      });
    });

    // Toggle locked buttons
    document.querySelectorAll('.toggle-locked').forEach(function(btn) {
      btn.addEventListener('click', function(e) {
        e.preventDefault();
        freechat.toggleLocked(this);
      });
    });

    // Subscription toggle buttons
    document.querySelectorAll('.subscription-toggle').forEach(function(btn) {
      btn.addEventListener('click', function(e) {
        e.preventDefault();
        freechat.toggleSubscription(this);
      });
    });

    // Reaction buttons
    document.querySelectorAll('.reaction-btn').forEach(function(btn) {
      btn.addEventListener('click', function(e) {
        e.preventDefault();
        freechat.addReaction(this);
      });
    });

    // Report buttons
    document.querySelectorAll('.report-btn').forEach(function(btn) {
      btn.addEventListener('click', function(e) {
        e.preventDefault();
        freechat.showReportModal(this.dataset.postId);
      });
    });

    // Delete buttons
    document.querySelectorAll('.delete-btn').forEach(function(btn) {
      btn.addEventListener('click', function(e) {
        e.preventDefault();
        freechat.deletePost(this);
      });
    });

    // Report form submission
    var reportForm = document.getElementById('reportForm');
    if (reportForm) {
      reportForm.addEventListener('submit', function(e) {
        e.preventDefault();
        freechat.submitReport(this);
      });
    }
  });

})();
