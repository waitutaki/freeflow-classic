<?php
/**
 * Freechat Extension - Topics Controller
 * Admin controller for managing topics
 */

namespace Freeflow\Extension\Freechat\Admin;

defined('_FFEXEC') or die;

use Freeflow\Core\Controller;
use Freeflow\Core\Database;
use Freeflow\Core\Language;
use Freeflow\Core\User;
use Freeflow\Core\Application;

class TopicsController extends Controller
{
  /**
   * Display list of topics
   */
  public function display()
  {
    $this->checkPermission('freechat.manage');
    
    $db = Database::getInstance();
    
    // Get filters
    $forumId = $this->input->getInt('forum_id', 0);
    $state = $this->input->getString('state', '');
    $type = $this->input->getString('type', '');
    
    $query = $db->getQuery(true)
      ->select('t.*, f.title as forum_title, u.name as author_name')
      ->from('#_ext_freechat_topics t')
      ->leftJoin('#_ext_freechat_forums f ON t.forum_id = f.id')
      ->leftJoin('#_users u ON t.created_by = u.id');
    
    if ($forumId) {
      $query->where('t.forum_id = ' . $forumId);
    }
    
    if (!empty($state)) {
      $query->where('t.state = ' . $db->quote($state));
    }
    
    if (!empty($type)) {
      $query->where('t.type = ' . $db->quote($type));
    }
    
    $query->order('t.created_at DESC');
    
    $topics = $db->setQuery($query)->loadObjectList();
    
    // Get forums for filter
    $forums = $db->getQuery(true)
      ->select('id, title')
      ->from('#_ext_freechat_forums')
      ->where('state = 1')
      ->order('title ASC')
      ->loadObjectList();
    
    $this->view->assign('topics', $topics);
    $this->view->assign('forums', $forums);
    $this->view->assign('filters', ['forum_id' => $forumId, 'state' => $state, 'type' => $type]);
    $this->view->setLayout('default');
    $this->view->display();
  }
  
  /**
   * View topic detail
   */
  public function view()
  {
    $this->checkPermission('freechat.manage');
    
    $id = $this->input->getInt('id', 0);
    
    if (!$id) {
      Application::enqueueMessage(Language::translate('COM_FREECHAT_NOT_FOUND'), 'error');
      $this->redirect('index.php?option=freechat&view=topics');
    }
    
    $db = Database::getInstance();
    
    $topic = $db->getQuery(true)
      ->select('t.*, f.title as forum_title, u.name as author_name')
      ->from('#_ext_freechat_topics t')
      ->leftJoin('#_ext_freechat_forums f ON t.forum_id = f.id')
      ->leftJoin('#_users u ON t.created_by = u.id')
      ->where('t.id = ' . $id)
      ->loadObject();
    
    if (!$topic) {
      Application::enqueueMessage(Language::translate('COM_FREECHAT_TOPIC_NOT_FOUND'), 'error');
      $this->redirect('index.php?option=freechat&view=topics');
    }
    
    $posts = $db->getQuery(true)
      ->select('p.*, u.name as author_name')
      ->from('#_ext_freechat_posts p')
      ->leftJoin('#_users u ON p.author_id = u.id')
      ->where('p.topic_id = ' . $id)
      ->where('p.state IN (\'published\', \'hidden\')')
      ->order('p.created_at ASC')
      ->loadObjectList();
    
    $this->view->assign('topic', $topic);
    $this->view->assign('posts', $posts);
    $this->view->setLayout('view');
    $this->view->display();
  }
  
  /**
   * Hide topic
   */
  public function hide()
  {
    $this->checkPermission('freechat.moderate');
    
    $id = $this->input->getInt('id', 0);
    
    if (!$id) {
      Application::enqueueMessage(Language::translate('COM_FREECHAT_NOT_FOUND'), 'error');
      $this->redirect('index.php?option=freechat&view=topics');
    }
    
    $db = Database::getInstance();
    
    $result = $db->update('#_ext_freechat_topics',
      ['state' => 'hidden', 'modified_at' => date('Y-m-d H:i:s')],
      ['id' => $id]
    );
    
    if ($result === false) {
      Application::enqueueMessage(Language::translate('COM_FREECHAT_ERROR'), 'error');
    } else {
      Application::enqueueMessage(Language::translate('COM_FREECHAT_SUCCESS'), 'success');
    }
    
    $this->redirect('index.php?option=freechat&view=topics');
  }
  
  /**
   * Show topic
   */
  public function show()
  {
    $this->checkPermission('freechat.moderate');
    
    $id = $this->input->getInt('id', 0);
    
    if (!$id) {
      Application::enqueueMessage(Language::translate('COM_FREECHAT_NOT_FOUND'), 'error');
      $this->redirect('index.php?option=freechat&view=topics');
    }
    
    $db = Database::getInstance();
    
    $result = $db->update('#_ext_freechat_topics',
      ['state' => 'open', 'modified_at' => date('Y-m-d H:i:s')],
      ['id' => $id]
    );
    
    if ($result === false) {
      Application::enqueueMessage(Language::translate('COM_FREECHAT_ERROR'), 'error');
    } else {
      Application::enqueueMessage(Language::translate('COM_FREECHAT_SUCCESS'), 'success');
    }
    
    $this->redirect('index.php?option=freechat&view=topics');
  }
  
  /**
   * Toggle sticky status
   */
  public function toggleSticky()
  {
    $this->checkPermission('freechat.moderate');
    
    $id = $this->input->getInt('id', 0);
    $isSticky = $this->input->getInt('sticky', 0);
    
    if (!$id) {
      echo json_encode(['success' => false, 'message' => 'Invalid ID']);
      return;
    }
    
    $db = Database::getInstance();
    
    $type = $isSticky ? 'sticky' : 'normal';
    
    $result = $db->update('#_ext_freechat_topics',
      ['type' => $type, 'modified_at' => date('Y-m-d H:i:s')],
      ['id' => $id]
    );
    
    echo json_encode([
      'success' => $result !== false,
      'sticky' => $isSticky,
      'icon' => $isSticky ? 'fa-thumbtack text-warning' : 'fa-regular fa-thumbtack'
    ]);
  }
  
  /**
   * Toggle locked status
   */
  public function toggleLocked()
  {
    $this->checkPermission('freechat.moderate');
    
    $id = $this->input->getInt('id', 0);
    $isLocked = $this->input->getInt('locked', 0);
    
    if (!$id) {
      echo json_encode(['success' => false, 'message' => 'Invalid ID']);
      return;
    }
    
    $db = Database::getInstance();
    
    $state = $isLocked ? 'locked' : 'open';
    
    $result = $db->update('#_ext_freechat_topics',
      ['state' => $state, 'modified_at' => date('Y-m-d H:i:s')],
      ['id' => $id]
    );
    
    echo json_encode([
      'success' => $result !== false,
      'locked' => $isLocked,
      'icon' => $isLocked ? 'fa-lock text-danger' : 'fa-lock-open text-success'
    ]);
  }
  
  /**
   * Delete topic
   */
  public function delete()
  {
    $this->checkPermission('freechat.moderate');
    
    $id = $this->input->getInt('id', 0);
    
    if (!$id) {
      Application::enqueueMessage(Language::translate('COM_FREECHAT_NOT_FOUND'), 'error');
      $this->redirect('index.php?option=freechat&view=topics');
    }
    
    $db = Database::getInstance();
    
    // Delete posts first (handled by CASCADE but let's be safe)
    $db->delete('#_ext_freechat_posts', ['topic_id' => $id]);
    $result = $db->delete('#_ext_freechat_topics', ['id' => $id]);
    
    if ($result === false) {
      Application::enqueueMessage(Language::translate('COM_FREECHAT_ERROR'), 'error');
    } else {
      Application::enqueueMessage(Language::translate('COM_FREECHAT_TOPIC_DELETED'), 'success');
    }
    
    $this->redirect('index.php?option=freechat&view=topics');
  }
}
