<?php
/**
 * Freechat Extension - Admin View - Category Edit Form
 */

defined('_FFEXEC') or die;

$category = isset($this->category) ? $this->category : null;
$isEdit = !empty($category);
?>
<div class="container-fluid">
  <div class="row mb-3">
    <div class="col">
      <h1 class="h3 mb-0">
        <i class="fa-solid fa-folder me-2"></i>
        <?php echo $isEdit ? Language::translate('COM_FREECHAT_CATEGORY_EDIT') : Language::translate('COM_FREECHAT_CATEGORY_NEW'); ?>
      </h1>
    </div>
  </div>

  <div class="card">
    <div class="card-body">
      <form action="index.php?option=freechat&view=categories&task=save" method="post" class="needs-validation" novalidate>
        <?php if ($isEdit): ?>
          <input type="hidden" name="id" value="<?php echo $category->id; ?>">
        <?php endif; ?>

        <div class="row mb-3">
          <div class="col-md-6">
            <label for="title" class="form-label"><?php echo Language::translate('COM_FREECHAT_CATEGORY_NEW'); ?> *</label>
            <input type="text" class="form-control" id="title" name="title" value="<?php echo $category->title ?? ''; ?>" required>
            <div class="invalid-feedback">Please enter a title</div>
          </div>
        </div>

        <div class="row mb-3">
          <div class="col-md-6">
            <label for="space_id" class="form-label"><?php echo Language::translate('COM_FREECHAT_SPACES'); ?> *</label>
            <select class="form-select" id="space_id" name="space_id" required>
              <option value="">Select a space</option>
              <?php foreach ($this->spaces as $space): ?>
                <option value="<?php echo $space->id; ?>" <?php echo ($category->space_id ?? 0) == $space->id ? 'selected' : ''; ?>>
                  <?php echo htmlspecialchars($space->title); ?>
                </option>
              <?php endforeach; ?>
            </select>
            <div class="invalid-feedback">Please select a space</div>
          </div>
        </div>

        <div class="row mb-3">
          <div class="col-md-6">
            <label for="parent_id" class="form-label"><?php echo Language::translate('COM_FREECHAT_CATEGORY_PARENT'); ?></label>
            <select class="form-select" id="parent_id" name="parent_id">
              <option value="0">None (top level)</option>
              <!-- Categories would be populated here via AJAX -->
            </select>
          </div>
        </div>

        <div class="row mb-3">
          <div class="col-md-6">
            <label for="description" class="form-label"><?php echo Language::translate('COM_FREECHAT_SPACE_DESCRIPTION'); ?></label>
            <textarea class="form-control" id="description" name="description" rows="3"><?php echo $category->description ?? ''; ?></textarea>
          </div>
        </div>

        <div class="row mb-3">
          <div class="col-md-3">
            <label for="threading_depth" class="form-label"><?php echo Language::translate('COM_FREECHAT_CATEGORY_THREADING'); ?></label>
            <input type="number" class="form-control" id="threading_depth" name="threading_depth" value="<?php echo $category->threading_depth ?? 3; ?>" min="1" max="10">
          </div>
          <div class="col-md-3">
            <label for="moderation_model" class="form-label"><?php echo Language::translate('COM_FREECHAT_CATEGORY_MODERATION'); ?></label>
            <select class="form-select" id="moderation_model" name="moderation_model">
              <option value="open" <?php echo ($category->moderation_model ?? 'open') == 'open' ? 'selected' : ''; ?>>
                <?php echo Language::translate('COM_FREECHAT_CATEGORY_MODERATION_OPEN'); ?>
              </option>
              <option value="premod" <?php echo ($category->moderation_model ?? 'open') == 'premod' ? 'selected' : ''; ?>>
                <?php echo Language::translate('COM_FREECHAT_CATEGORY_MODERATION_PREMOD'); ?>
              </option>
              <option value="postmod" <?php echo ($category->moderation_model ?? 'open') == 'postmod' ? 'selected' : ''; ?>>
                <?php echo Language::translate('COM_FREECHAT_CATEGORY_MODERATION_POSTMOD'); ?>
              </option>
            </select>
          </div>
        </div>

        <div class="row mb-3">
          <div class="col-md-3">
            <div class="form-check form-switch">
              <input class="form-check-input" type="checkbox" id="allow_tags" name="allow_tags" value="1" <?php echo ($category->allow_tags ?? 1) == 1 ? 'checked' : ''; ?>>
              <label class="form-check-label" for="allow_tags"><?php echo Language::translate('COM_FREECHAT_CATEGORY_TAGS'); ?></label>
            </div>
          </div>
          <div class="col-md-3">
            <div class="form-check form-switch">
              <input class="form-check-input" type="checkbox" id="allow_revisions" name="allow_revisions" value="1" <?php echo ($category->allow_revisions ?? 1) == 1 ? 'checked' : ''; ?>>
              <label class="form-check-label" for="allow_revisions"><?php echo Language::translate('COM_FREECHAT_CATEGORY_REVISIONS'); ?></label>
            </div>
          </div>
        </div>

        <div class="row mb-3">
          <div class="col-md-3">
            <label for="ordering" class="form-label"><?php echo Language::translate('COM_FREECHAT_SPACE_ORDERING'); ?></label>
            <input type="number" class="form-control" id="ordering" name="ordering" value="<?php echo $category->ordering ?? 0; ?>" min="0">
          </div>
          <div class="col-md-3">
            <label for="state" class="form-label"><?php echo Language::translate('COM_FREECHAT_SPACE_STATE'); ?></label>
            <select class="form-select" id="state" name="state">
              <option value="1" <?php echo ($category->state ?? 1) == 1 ? 'selected' : ''; ?>>
                <?php echo Language::translate('COM_FREECHAT_SPACE_PUBLISHED'); ?>
              </option>
              <option value="0" <?php echo ($category->state ?? 1) == 0 ? 'selected' : ''; ?>>
                <?php echo Language::translate('COM_FREECHAT_SPACE_UNPUBLISHED'); ?>
              </option>
            </select>
          </div>
        </div>

        <div class="row">
          <div class="col">
            <button type="submit" class="btn btn-primary">
              <i class="fa-solid fa-check me-1"></i>
              <?php echo Language::translate('COM_FREECHAT_SAVE'); ?>
            </button>
            <a href="index.php?option=freechat&view=categories" class="btn btn-secondary">
              <i class="fa-solid fa-xmark me-1"></i>
              <?php echo Language::translate('COM_FREECHAT_CANCEL'); ?>
            </a>
          </div>
        </div>
      </form>
    </div>
  </div>
</div>
