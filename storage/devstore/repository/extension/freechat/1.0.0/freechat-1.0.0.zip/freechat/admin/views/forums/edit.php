<?php
/**
 * Freechat Extension - Admin View - Forum Edit Form
 */

defined('_FFEXEC') or die;

$forum = isset($this->forum) ? $this->forum : null;
$isEdit = !empty($forum);
?>
<div class="container-fluid">
  <div class="row mb-3">
    <div class="col">
      <h1 class="h3 mb-0">
        <i class="fa-solid fa-comments me-2"></i>
        <?php echo $isEdit ? Language::translate('COM_FREECHAT_FORUM_EDIT') : Language::translate('COM_FREECHAT_FORUM_NEW'); ?>
      </h1>
    </div>
  </div>

  <div class="card">
    <div class="card-body">
      <form action="index.php?option=freechat&view=forums&task=save" method="post" class="needs-validation" novalidate>
        <?php if ($isEdit): ?>
          <input type="hidden" name="id" value="<?php echo $forum->id; ?>">
        <?php endif; ?>

        <div class="row mb-3">
          <div class="col-md-6">
            <label for="title" class="form-label"><?php echo Language::translate('COM_FREECHAT_FORUMS'); ?> *</label>
            <input type="text" class="form-control" id="title" name="title" value="<?php echo $forum->title ?? ''; ?>" required>
            <div class="invalid-feedback">Please enter a title</div>
          </div>
        </div>

        <div class="row mb-3">
          <div class="col-md-6">
            <label for="category_id" class="form-label"><?php echo Language::translate('COM_FREECHAT_FORUM_CATEGORY'); ?> *</label>
            <select class="form-select" id="category_id" name="category_id" required>
              <option value="">Select a category</option>
              <?php foreach ($this->categories as $cat): ?>
                <option value="<?php echo $cat->id; ?>" <?php echo ($forum->category_id ?? 0) == $cat->id ? 'selected' : ''; ?>>
                  <?php echo htmlspecialchars($cat->space_title . ' - ' . $cat->title); ?>
                </option>
              <?php endforeach; ?>
            </select>
            <div class="invalid-feedback">Please select a category</div>
          </div>
        </div>

        <div class="row mb-3">
          <div class="col-md-6">
            <label for="description" class="form-label"><?php echo Language::translate('COM_FREECHAT_SPACE_DESCRIPTION'); ?></label>
            <textarea class="form-control" id="description" name="description" rows="3"><?php echo $forum->description ?? ''; ?></textarea>
          </div>
        </div>

        <div class="row mb-3">
          <div class="col-md-12">
            <div class="form-check form-switch">
              <input class="form-check-input" type="checkbox" id="override_category_settings" name="override_category_settings" value="1" <?php echo ($forum->override_category_settings ?? 0) == 1 ? 'checked' : ''; ?> onchange="toggleOverrideSettings()">
              <label class="form-check-label" for="override_category_settings"><?php echo Language::translate('COM_FREECHAT_FORUM_OVERRIDE'); ?></label>
            </div>
          </div>
        </div>

        <div id="override-settings" class="<?php echo ($forum->override_category_settings ?? 0) == 1 ? '' : 'd-none'; ?>">
          <div class="row mb-3">
            <div class="col-md-3">
              <label for="threading_depth" class="form-label"><?php echo Language::translate('COM_FREECHAT_CATEGORY_THREADING'); ?></label>
              <input type="number" class="form-control" id="threading_depth" name="threading_depth" value="<?php echo $forum->threading_depth ?? ''; ?>" min="1" max="10">
            </div>
            <div class="col-md-3">
              <label for="moderation_model" class="form-label"><?php echo Language::translate('COM_FREECHAT_CATEGORY_MODERATION'); ?></label>
              <select class="form-select" id="moderation_model" name="moderation_model">
                <option value="">Use category default</option>
                <option value="open" <?php echo ($forum->moderation_model ?? '') == 'open' ? 'selected' : ''; ?>>
                  <?php echo Language::translate('COM_FREECHAT_CATEGORY_MODERATION_OPEN'); ?>
                </option>
                <option value="premod" <?php echo ($forum->moderation_model ?? '') == 'premod' ? 'selected' : ''; ?>>
                  <?php echo Language::translate('COM_FREECHAT_CATEGORY_MODERATION_PREMOD'); ?>
                </option>
                <option value="postmod" <?php echo ($forum->moderation_model ?? '') == 'postmod' ? 'selected' : ''; ?>>
                  <?php echo Language::translate('COM_FREECHAT_CATEGORY_MODERATION_POSTMOD'); ?>
                </option>
              </select>
            </div>
          </div>

          <div class="row mb-3">
            <div class="col-md-3">
              <div class="form-check form-switch">
                <input class="form-check-input" type="checkbox" id="allow_tags" name="allow_tags" value="1" <?php echo ($forum->allow_tags ?? -1) == 1 ? 'checked' : ''; ?>>
                <label class="form-check-label" for="allow_tags"><?php echo Language::translate('COM_FREECHAT_CATEGORY_TAGS'); ?></label>
              </div>
            </div>
            <div class="col-md-3">
              <div class="form-check form-switch">
                <input class="form-check-input" type="checkbox" id="allow_revisions" name="allow_revisions" value="1" <?php echo ($forum->allow_revisions ?? -1) == 1 ? 'checked' : ''; ?>>
                <label class="form-check-label" for="allow_revisions"><?php echo Language::translate('COM_FREECHAT_CATEGORY_REVISIONS'); ?></label>
              </div>
            </div>
          </div>
        </div>

        <div class="row mb-3">
          <div class="col-md-3">
            <label for="ordering" class="form-label"><?php echo Language::translate('COM_FREECHAT_SPACE_ORDERING'); ?></label>
            <input type="number" class="form-control" id="ordering" name="ordering" value="<?php echo $forum->ordering ?? 0; ?>" min="0">
          </div>
          <div class="col-md-3">
            <label for="state" class="form-label"><?php echo Language::translate('COM_FREECHAT_SPACE_STATE'); ?></label>
            <select class="form-select" id="state" name="state">
              <option value="1" <?php echo ($forum->state ?? 1) == 1 ? 'selected' : ''; ?>>
                <?php echo Language::translate('COM_FREECHAT_SPACE_PUBLISHED'); ?>
              </option>
              <option value="0" <?php echo ($forum->state ?? 1) == 0 ? 'selected' : ''; ?>>
                <?php echo Language::translate('COM_FREECHAT_SPACE_UNPUBLISHED'); ?>
              </option>
            </select>
          </div>
        </div>

        <div class="row">
          <div class="col">
            <button type="submit" class="btn btn-primary">
              <i class="fa-solid fa-check me-1"></i>
              <?php echo Language::translate('COM_FREECHAT_SAVE'); ?>
            </button>
            <a href="index.php?option=freechat&view=forums" class="btn btn-secondary">
              <i class="fa-solid fa-xmark me-1"></i>
              <?php echo Language::translate('COM_FREECHAT_CANCEL'); ?>
            </a>
          </div>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
function toggleOverrideSettings() {
  var checkbox = document.getElementById('override_category_settings');
  var settingsDiv = document.getElementById('override-settings');
  
  if (checkbox.checked) {
    settingsDiv.classList.remove('d-none');
  } else {
    settingsDiv.classList.add('d-none');
  }
}
</script>
