<?php
/**
 * Freechat Extension - Forums Controller
 * Admin controller for managing forums
 */

namespace Freeflow\Extension\Freechat\Admin;

defined('_FFEXEC') or die;

use Freeflow\Core\Controller;
use Freeflow\Core\Database;
use Freeflow\Core\Language;
use Freeflow\Core\User;
use Freeflow\Core\Application;

class ForumsController extends Controller
{
  /**
   * Display list of forums
   */
  public function display()
  {
    $this->checkPermission('freechat.forums.manage');
    
    $db = Database::getInstance();
    
    $query = $db->getQuery(true)
      ->select('f.*, c.title as category_title, s.title as space_title')
      ->from('#_ext_freechat_forums f')
      ->leftJoin('#_ext_freechat_categories c ON f.category_id = c.id')
      ->leftJoin('#_ext_freechat_spaces s ON c.space_id = s.id')
      ->order('f.ordering ASC');
    
    $forums = $db->setQuery($query)->loadObjectList();
    
    // Get categories for dropdown
    $categories = $db->getQuery(true)
      ->select('c.id, c.title, s.title as space_title')
      ->from('#_ext_freechat_categories c')
      ->leftJoin('#_ext_freechat_spaces s ON c.space_id = s.id')
      ->where('c.state = 1')
      ->order('s.title ASC, c.ordering ASC')
      ->loadObjectList();
    
    $this->view->assign('forums', $forums);
    $this->view->assign('categories', $categories);
    $this->view->setLayout('default');
    $this->view->display();
  }
  
  /**
   * New forum form
   */
  public function add()
  {
    $this->checkPermission('freechat.forums.manage');
    
    $db = Database::getInstance();
    
    $categories = $db->getQuery(true)
      ->select('c.id, c.title, s.title as space_title')
      ->from('#_ext_freechat_categories c')
      ->leftJoin('#_ext_freechat_spaces s ON c.space_id = s.id')
      ->where('c.state = 1')
      ->order('s.title ASC, c.ordering ASC')
      ->loadObjectList();
    
    $this->view->assign('categories', $categories);
    $this->view->setLayout('edit');
    $this->view->display();
  }
  
  /**
   * Edit forum form
   */
  public function edit()
  {
    $this->checkPermission('freechat.forums.manage');
    
    $id = $this->input->getInt('id', 0);
    
    if (!$id) {
      Application::enqueueMessage(Language::translate('COM_FREECHAT_NOT_FOUND'), 'error');
      $this->redirect('index.php?option=freechat&view=forums');
    }
    
    $db = Database::getInstance();
    
    $forum = $db->getQuery(true)
      ->select('*')
      ->from('#_ext_freechat_forums')
      ->where('id = ' . $id)
      ->loadObject();
    
    if (!$forum) {
      Application::enqueueMessage(Language::translate('COM_FREECHAT_NOT_FOUND'), 'error');
      $this->redirect('index.php?option=freechat&view=forums');
    }
    
    $categories = $db->getQuery(true)
      ->select('c.id, c.title, s.title as space_title')
      ->from('#_ext_freechat_categories c')
      ->leftJoin('#_ext_freechat_spaces s ON c.space_id = s.id')
      ->where('c.state = 1')
      ->order('s.title ASC, c.ordering ASC')
      ->loadObjectList();
    
    $this->view->assign('forum', $forum);
    $this->view->assign('categories', $categories);
    $this->view->setLayout('edit');
    $this->view->display();
  }
  
  /**
   * Save forum
   */
  public function save()
  {
    $this->checkPermission('freechat.forums.manage');
    
    $id = $this->input->getInt('id', 0);
    $categoryId = $this->input->getInt('category_id', 0);
    $title = $this->input->getString('title', '');
    $description = $this->input->getRaw('description', '');
    $overrideSettings = $this->input->getInt('override_category_settings', 0);
    $threadingDepth = $this->input->getInt('threading_depth', 0);
    $moderationModel = $this->input->getString('moderation_model', '');
    $allowTags = $this->input->getInt('allow_tags', -1);
    $allowRevisions = $this->input->getInt('allow_revisions', -1);
    $ordering = $this->input->getInt('ordering', 0);
    $state = $this->input->getInt('state', 1);
    
    if (empty($title) || !$categoryId) {
      Application::enqueueMessage(Language::translate('COM_FREECHAT_ERROR_INVALID_INPUT'), 'error');
      $redirectUrl = $id ? 'index.php?option=freechat&view=forums&task=edit&id=' . $id : 'index.php?option=freechat&view=forums&task=add';
      $this->redirect($redirectUrl);
    }
    
    $db = Database::getInstance();
    $user = User::getInstance();
    $now = date('Y-m-d H:i:s');
    
    $data = [
      'category_id' => $categoryId,
      'title' => $title,
      'slug' => $this->generateSlug($title),
      'description' => $description,
      'override_category_settings' => $overrideSettings,
      'ordering' => $ordering,
      'state' => $state,
      'modified_at' => $now,
      'modified_by' => $user->id
    ];
    
    // Only set nullable fields if overriding
    if ($overrideSettings) {
      if ($threadingDepth > 0) {
        $data['threading_depth'] = $threadingDepth;
      }
      if (!empty($moderationModel)) {
        $data['moderation_model'] = $moderationModel;
      }
      if ($allowTags >= 0) {
        $data['allow_tags'] = $allowTags;
      }
      if ($allowRevisions >= 0) {
        $data['allow_revisions'] = $allowRevisions;
      }
    }
    
    if ($id) {
      $data['id'] = $id;
      $result = $db->update('#_ext_freechat_forums', $data, 'id');
    } else {
      $data['created_at'] = $now;
      $data['created_by'] = $user->id;
      $result = $db->insert('#_ext_freechat_forums', $data);
      $id = $db->insertid();
    }
    
    if ($result === false) {
      Application::enqueueMessage(Language::translate('COM_FREECHAT_ERROR'), 'error');
    } else {
      Application::enqueueMessage(Language::translate('COM_FREECHAT_FORUM_SAVED'), 'success');
    }
    
    $this->redirect('index.php?option=freechat&view=forums');
  }
  
  /**
   * Delete forum
   */
  public function delete()
  {
    $this->checkPermission('freechat.forums.manage');
    
    $id = $this->input->getInt('id', 0);
    
    if (!$id) {
      Application::enqueueMessage(Language::translate('COM_FREECHAT_NOT_FOUND'), 'error');
      $this->redirect('index.php?option=freechat&view=forums');
    }
    
    $db = Database::getInstance();
    
    // Check if forum has topics
    $count = $db->getQuery(true)
      ->select('COUNT(*)')
      ->from('#_ext_freechat_topics')
      ->where('forum_id = ' . $id)
      ->loadResult();
    
    if ($count > 0) {
      Application::enqueueMessage('Cannot delete forum with topics. Delete or move topics first.', 'error');
      $this->redirect('index.php?option=freechat&view=forums');
    }
    
    $result = $db->delete('#_ext_freechat_forums', ['id' => $id]);
    
    if ($result === false) {
      Application::enqueueMessage(Language::translate('COM_FREECHAT_ERROR'), 'error');
    } else {
      Application::enqueueMessage(Language::translate('COM_FREECHAT_FORUM_DELETED'), 'success');
    }
    
    $this->redirect('index.php?option=freechat&view=forums');
  }
  
  /**
   * Toggle state
   */
  public function toggleState()
  {
    $this->checkPermission('freechat.forums.manage');
    
    $id = $this->input->getInt('id', 0);
    $newState = $this->input->getInt('state', 0);
    
    if (!$id) {
      echo json_encode(['success' => false, 'message' => 'Invalid ID']);
      return;
    }
    
    $db = Database::getInstance();
    
    $result = $db->update('#_ext_freechat_forums',
      ['state' => $newState, 'modified_at' => date('Y-m-d H:i:s')],
      ['id' => $id]
    );
    
    echo json_encode([
      'success' => $result !== false,
      'newState' => $newState,
      'icon' => $newState ? 'fa-circle-check text-success' : 'fa-circle-xmark text-danger'
    ]);
  }
  
  private function generateSlug($title)
  {
    $slug = strtolower(trim($title));
    $slug = preg_replace('/[^a-z0-9-]/', '-', $slug);
    $slug = preg_replace('/-+/', '-', $slug);
    $slug = trim($slug, '-');
    
    $db = Database::getInstance();
    $i = 1;
    $originalSlug = $slug;
    
    while (true) {
      $exists = $db->getQuery(true)
        ->select('COUNT(*)')
        ->from('#_ext_freechat_forums')
        ->where('slug = ' . $db->quote($slug))
        ->loadResult();
      
      if (!$exists) {
        break;
      }
      
      $slug = $originalSlug . '-' . $i++;
    }
    
    return $slug;
  }
}
