<?php
/**
 * Freechat Extension - Reports Controller
 * Admin controller for managing user reports
 */

namespace Freeflow\Extension\Freechat\Admin;

defined('_FFEXEC') or die;

use Freeflow\Core\Controller;
use Freeflow\Core\Database;
use Freeflow\Core\Language;
use Freeflow\Core\User;
use Freeflow\Core\Application;

class ReportsController extends Controller
{
  /**
   * Display list of reports
   */
  public function display()
  {
    $this->checkPermission('freechat.reports.manage');
    
    $db = Database::getInstance();
    
    // Get filters
    $status = $this->input->getString('status', '');
    $type = $this->input->getString('type', '');
    
    $query = $db->getQuery(true)
      ->select('r.*, reporter.name as reporter_name, reviewer.name as reviewer_name')
      ->from('#_ext_freechat_reports r')
      ->leftJoin('#_users reporter ON r.reporter_id = reporter.id')
      ->leftJoin('#_users reviewer ON r.reviewer_id = reviewer.id');
    
    if (!empty($status)) {
      $query->where('r.status = ' . $db->quote($status));
    }
    
    if (!empty($type)) {
      $query->where('r.type = ' . $db->quote($type));
    }
    
    $query->order('r.created_at DESC');
    
    $reports = $db->setQuery($query)->loadObjectList();
    
    $this->view->assign('reports', $reports);
    $this->view->assign('filters', ['status' => $status, 'type' => $type]);
    $this->view->setLayout('default');
    $this->view->display();
  }
  
  /**
   * Review report
   */
  public function review()
  {
    $this->checkPermission('freechat.reports.manage');
    
    $id = $this->input->getInt('id', 0);
    $status = $this->input->getString('status', '');
    $notes = $this->input->getString('notes', '');
    
    if (!$id || !in_array($status, ['reviewed', 'dismissed', 'resolved'])) {
      Application::enqueueMessage(Language::translate('COM_FREECHAT_ERROR_INVALID_INPUT'), 'error');
      $this->redirect('index.php?option=freechat&view=reports');
    }
    
    $db = Database::getInstance();
    $user = User::getInstance();
    
    $result = $db->update('#_ext_freechat_reports',
      [
        'status' => $status,
        'reviewer_id' => $user->id,
        'reviewed_at' => date('Y-m-d H:i:s')
      ],
      ['id' => $id]
    );
    
    if ($result === false) {
      Application::enqueueMessage(Language::translate('COM_FREECHAT_ERROR'), 'error');
    } else {
      Application::enqueueMessage(Language::translate('COM_FREECHAT_SUCCESS'), 'success');
    }
    
    $this->redirect('index.php?option=freechat&view=reports');
  }
  
  /**
   * Mark report as resolved
   */
  public function resolve()
  {
    $this->checkPermission('freechat.reports.manage');
    
    $id = $this->input->getInt('id', 0);
    
    if (!$id) {
      echo json_encode(['success' => false]);
      return;
    }
    
    $db = Database::getInstance();
    $user = User::getInstance();
    
    $result = $db->update('#_ext_freechat_reports',
      [
        'status' => 'resolved',
        'reviewer_id' => $user->id,
        'reviewed_at' => date('Y-m-d H:i:s')
      ],
      ['id' => $id]
    );
    
    echo json_encode(['success' => $result !== false]);
  }
  
  /**
   * Dismiss report
   */
  public function dismiss()
  {
    $this->checkPermission('freechat.reports.manage');
    
    $id = $this->input->getInt('id', 0);
    
    if (!$id) {
      echo json_encode(['success' => false]);
      return;
    }
    
    $db = Database::getInstance();
    $user = User::getInstance();
    
    $result = $db->update('#_ext_freechat_reports',
      [
        'status' => 'dismissed',
        'reviewer_id' => $user->id,
        'reviewed_at' => date('Y-m-d H:i:s')
      ],
      ['id' => $id]
    );
    
    echo json_encode(['success' => $result !== false]);
  }
  
  /**
   * Take action on reported item
   */
  public function action()
  {
    $this->checkPermission('freechat.reports.manage');
    
    $id = $this->input->getInt('id', 0);
    $action = $this->input->getString('action', '');
    
    if (!$id || !in_array($action, ['hide_post', 'hide_topic', 'warn_user', 'ban_user'])) {
      echo json_encode(['success' => false, 'message' => 'Invalid parameters']);
      return;
    }
    
    $db = Database::getInstance();
    
    // Get report to find the item
    $report = $db->getQuery(true)
      ->select('*')
      ->from('#_ext_freechat_reports')
      ->where('id = ' . $id)
      ->loadObject();
    
    if (!$report) {
      echo json_encode(['success' => false, 'message' => 'Report not found']);
      return;
    }
    
    switch ($action) {
      case 'hide_post':
        if ($report->type === 'post') {
          $db->update('#_ext_freechat_posts', ['state' => 'hidden'], ['id' => $report->item_id]);
        }
        break;
        
      case 'hide_topic':
        if ($report->type === 'topic') {
          $db->update('#_ext_freechat_topics', ['state' => 'hidden'], ['id' => $report->item_id]);
        }
        break;
        
      case 'warn_user':
        // Would integrate with core user management
        break;
        
      case 'ban_user':
        // Would integrate with core user management
        break;
    }
    
    // Mark report as resolved
    $user = User::getInstance();
    $db->update('#_ext_freechat_reports',
      [
        'status' => 'resolved',
        'reviewer_id' => $user->id,
        'reviewed_at' => date('Y-m-d H:i:s')
      ],
      ['id' => $id]
    );
    
    echo json_encode(['success' => true]);
  }
}
