<?php
/**
 * Freechat Extension - Posts Controller
 * Site controller for creating and editing posts
 */

namespace Freeflow\Extension\Freechat\Site;

defined('_FFEXEC') or die;

use Freeflow\Core\Controller;
use Freeflow\Core\Database;
use Freeflow\Core\Language;
use Freeflow\Core\User;
use Freeflow\Core\Application;

class PostsController extends Controller
{
  /**
   * Create reply form
   */
  public function reply()
  {
    $user = User::getInstance();
    
    if (!$user->id) {
      Application::redirect('index.php?option=users&view=login&return=' . urlencode(Application::getUri()));
    }
    
    if (!$user->can('freechat.posts.create')) {
      Application::enqueueMessage(Language::translate('COM_FREECHAT_ERROR_PERMISSION_DENIED'), 'error');
      Application::redirect('index.php?option=freechat');
    }
    
    $topicId = $this->input->getInt('topic_id', 0);
    $quoteId = $this->input->getInt('quote_id', 0);
    
    if (!$topicId) {
      Application::enqueueMessage(Language::translate('COM_FREECHAT_NOT_FOUND'), 'error');
      Application::redirect('index.php?option=freechat');
    }
    
    $db = Database::getInstance();
    
    // Get topic
    $topic = $db->getQuery(true)
      ->select('*')
      ->from('#_ext_freechat_topics')
      ->where('id = ' . $topicId)
      ->loadObject();
    
    if (!$topic || $topic->state == 'locked') {
      Application::enqueueMessage(Language::translate('COM_FREECHAT_ERROR_TOPIC_LOCKED'), 'error');
      Application::redirect('index.php?option=freechat&view=topics&task=view&id=' . $topicId);
    }
    
    // Get quote if specified
    $quoteContent = '';
    if ($quoteId) {
      $quotedPost = $db->getQuery(true)
        ->select('p.*, u.name')
        ->from('#_ext_freechat_posts p')
        ->leftJoin('#_users u ON p.author_id = u.id')
        ->where('p.id = ' . $quoteId)
        ->where('p.topic_id = ' . $topicId)
        ->loadObject();
      
      if ($quotedPost) {
        $quoteContent = '[quote="' . $quotedPost->name . '"]' . $quotedPost->content . '[/quote]';
      }
    }
    
    $this->view->assign('topic', $topic);
    $this->view->assign('quoteContent', $quoteContent);
    $this->view->setLayout('reply');
    $this->view->display();
  }
  
  /**
   * Save reply
   */
  public function save()
  {
    $user = User::getInstance();
    
    if (!$user->id) {
      Application::enqueueMessage(Language::translate('COM_FREECHAT_PLEASE_LOGIN'), 'error');
      Application::redirect('index.php?option=users&view=login');
    }
    
    if (!$user->can('freechat.posts.create')) {
      Application::enqueueMessage(Language::translate('COM_FREECHAT_ERROR_PERMISSION_DENIED'), 'error');
      Application::redirect('index.php?option=freechat');
    }
    
    $topicId = $this->input->getInt('topic_id', 0);
    $content = $this->input->getRaw('content', '');
    $parentId = $this->input->getInt('parent_id', 0);
    
    if (!$topicId || empty($content)) {
      Application::enqueueMessage(Language::translate('COM_FREECHAT_ERROR_INVALID_INPUT'), 'error');
      Application::redirect('index.php?option=freechat&view=posts&task=reply&topic_id=' . $topicId);
    }
    
    $db = Database::getInstance();
    
    // Get topic and check if locked
    $topic = $db->getQuery(true)
      ->select('t.*, f.moderation_model as forum_moderation, c.moderation_model as cat_moderation')
      ->from('#_ext_freechat_topics t')
      ->leftJoin('#_ext_freechat_forums f ON t.forum_id = f.id')
      ->leftJoin('#_ext_freechat_categories c ON f.category_id = c.id')
      ->where('t.id = ' . $topicId)
      ->loadObject();
    
    if (!$topic) {
      Application::enqueueMessage(Language::translate('COM_FREECHAT_TOPIC_NOT_FOUND'), 'error');
      Application::redirect('index.php?option=freechat');
    }
    
    if ($topic->state == 'locked') {
      Application::enqueueMessage(Language::translate('COM_FREECHAT_ERROR_TOPIC_LOCKED'), 'error');
      Application::redirect('index.php?option=freechat&view=topics&task=view&id=' . $topicId);
    }
    
    // Determine moderation state
    $moderationModel = $topic->override_category_settings ? $topic->forum_moderation : $topic->cat_moderation;
    $postState = ($moderationModel == 'premod') ? 'hidden' : 'published';
    
    $now = date('Y-m-d H:i:s');
    $ipAddress = $_SERVER['REMOTE_ADDR'] ?? '';
    
    // Create post
    $postData = [
      'topic_id' => $topicId,
      'parent_id' => $parentId,
      'author_id' => $user->id,
      'content' => $content,
      'content_html' => $this->processContent($content),
      'state' => $postState,
      'created_at' => $now,
      'ip_address' => $ipAddress
    ];
    
    $result = $db->insert('#_ext_freechat_posts', $postData);
    $postId = $db->insertid();
    
    if (!$result) {
      Application::enqueueMessage(Language::translate('COM_FREECHAT_ERROR'), 'error');
      Application::redirect('index.php?option=freechat&view=posts&task=reply&topic_id=' . $topicId);
    }
    
    // Update topic stats
    $replyCount = $db->getQuery(true)
      ->select('COUNT(*)')
      ->from('#_ext_freechat_posts')
      ->where('topic_id = ' . $topicId)
      ->where('state = ' . $db->quote('published'))
      ->loadResult() - 1;
    
    $db->update('#_ext_freechat_topics', [
      'reply_count' => $replyCount,
      'last_post_id' => $postId,
      'last_post_at' => $now,
      'last_post_by' => $user->id
    ], ['id' => $topicId]);
    
    // Notify subscribers
    $this->notifySubscribers($topicId, $postId, $user->id);
    
    Application::enqueueMessage(Language::translate('COM_FREECHAT_POST_SAVED'), 'success');
    Application::redirect('index.php?option=freechat&view=topics&task=view&id=' . $topicId . '#post-' . $postId);
  }
  
  /**
   * Edit post form
   */
  public function edit()
  {
    $user = User::getInstance();
    
    if (!$user->id) {
      Application::redirect('index.php?option=users&view=login&return=' . urlencode(Application::getUri()));
    }
    
    $postId = $this->input->getInt('id', 0);
    
    if (!$postId) {
      Application::enqueueMessage(Language::translate('COM_FREECHAT_NOT_FOUND'), 'error');
      Application::redirect('index.php?option=freechat');
    }
    
    $db = Database::getInstance();
    
    $post = $db->getQuery(true)
      ->select('p.*, t.title as topic_title, t.forum_id')
      ->from('#_ext_freechat_posts p')
      ->leftJoin('#_ext_freechat_topics t ON p.topic_id = t.id')
      ->where('p.id = ' . $postId)
      ->loadObject();
    
    if (!$post) {
      Application::enqueueMessage(Language::translate('COM_FREECHAT_POST_NOT_FOUND'), 'error');
      Application::redirect('index.php?option=freechat');
    }
    
    // Check permissions
    $canEdit = ($user->id == $post->author_id && $user->can('freechat.posts.edit')) || $user->can('freechat.moderate');
    
    if (!$canEdit) {
      Application::enqueueMessage(Language::translate('COM_FREECHAT_ERROR_PERMISSION_DENIED'), 'error');
      Application::redirect('index.php?option=freechat&view=topics&task=view&id=' . $post->topic_id);
    }
    
    // Check if revisions are allowed
    $forum = $db->getQuery(true)
      ->select('f.allow_revisions, c.allow_revisions as cat_allow_revisions')
      ->from('#_ext_freechat_forums f')
      ->leftJoin('#_ext_freechat_categories c ON f.category_id = c.id')
      ->where('f.id = ' . $post->forum_id)
      ->loadObject();
    
    $allowRevisions = $forum->override_category_settings ? $forum->allow_revisions : $forum->cat_allow_revisions;
    
    // Get revision history if allowed
    $revisions = [];
    if ($allowRevisions) {
      $revisions = $db->getQuery(true)
        ->select('*')
        ->from('#_ext_freechat_revisions')
        ->where('post_id = ' . $postId)
        ->order('created_at DESC')
        ->loadObjectList();
    }
    
    $this->view->assign('post', $post);
    $this->view->assign('revisions', $revisions);
    $this->view->assign('allowRevisions', $allowRevisions);
    $this->view->setLayout('edit');
    $this->view->display();
  }
  
  /**
   * Save edited post
   */
  public function update()
  {
    $user = User::getInstance();
    
    if (!$user->id) {
      Application::enqueueMessage(Language::translate('COM_FREECHAT_PLEASE_LOGIN'), 'error');
      Application::redirect('index.php?option=users&view=login');
    }
    
    $postId = $this->input->getInt('id', 0);
    $content = $this->input->getRaw('content', '');
    $reason = $this->input->getString('edit_reason', '');
    
    if (!$postId || empty($content)) {
      Application::enqueueMessage(Language::translate('COM_FREECHAT_ERROR_INVALID_INPUT'), 'error');
      Application::redirect('index.php?option=freechat&view=posts&task=edit&id=' . $postId);
    }
    
    $db = Database::getInstance();
    
    $post = $db->getQuery(true)
      ->select('*')
      ->from('#_ext_freechat_posts')
      ->where('id = ' . $postId)
      ->loadObject();
    
    if (!$post) {
      Application::enqueueMessage(Language::translate('COM_FREECHAT_POST_NOT_FOUND'), 'error');
      Application::redirect('index.php?option=freechat');
    }
    
    // Check permissions
    $canEdit = ($user->id == $post->author_id && $user->can('freechat.posts.edit')) || $user->can('freechat.moderate');
    
    if (!$canEdit) {
      Application::enqueueMessage(Language::translate('COM_FREECHAT_ERROR_PERMISSION_DENIED'), 'error');
      Application::redirect('index.php?option=freechat&view=topics&task=view&id=' . $post->topic_id);
    }
    
    // Save revision if content changed
    if ($post->content !== $content) {
      $db->insert('#_ext_freechat_revisions', [
        'post_id' => $postId,
        'content' => $post->content,
        'content_html' => $post->content_html,
        'created_at' => date('Y-m-d H:i:s'),
        'created_by' => $user->id
      ]);
      
      // Update post
      $db->update('#_ext_freechat_posts', [
        'content' => $content,
        'content_html' => $this->processContent($content),
        'modified_at' => date('Y-m-d H:i:s'),
        'modified_by' => $user->id
      ], ['id' => $postId]);
    }
    
    Application::enqueueMessage(Language::translate('COM_FREECHAT_POST_SAVED'), 'success');
    Application::redirect('index.php?option=freechat&view=topics&task=view&id=' . $post->topic_id . '#post-' . $postId);
  }
  
  /**
   * Delete post (soft delete)
   */
  public function delete()
  {
    $user = User::getInstance();
    
    if (!$user->id) {
      echo json_encode(['success' => false, 'message' => 'Please login']);
      return;
    }
    
    $postId = $this->input->getInt('id', 0);
    
    if (!$postId) {
      echo json_encode(['success' => false, 'message' => 'Invalid post']);
      return;
    }
    
    $db = Database::getInstance();
    
    $post = $db->getQuery(true)
      ->select('*')
      ->from('#_ext_freechat_posts')
      ->where('id = ' . $postId)
      ->loadObject();
    
    if (!$post) {
      echo json_encode(['success' => false, 'message' => 'Post not found']);
      return;
    }
    
    // Check permissions
    $canDelete = ($user->id == $post->author_id && $user->can('freechat.posts.delete')) || $user->can('freechat.moderate');
    
    if (!$canDelete) {
      echo json_encode(['success' => false, 'message' => 'Permission denied']);
      return;
    }
    
    $result = $db->update('#_ext_freechat_posts', ['state' => 'soft_deleted'], ['id' => $postId]);
    
    echo json_encode(['success' => $result !== false]);
  }
  
  /**
   * Add reaction
   */
  public function react()
  {
    $user = User::getInstance();
    
    if (!$user->id) {
      echo json_encode(['success' => false, 'message' => 'Please login']);
      return;
    }
    
    $postId = $this->input->getInt('post_id', 0);
    $type = $this->input->getString('type', 'like');
    
    if (!$postId || !in_array($type, ['like', 'dislike', 'love', 'laugh'])) {
      echo json_encode(['success' => false, 'message' => 'Invalid parameters']);
      return;
    }
    
    $db = Database::getInstance();
    
    // Check if user already reacted
    $existing = $db->getQuery(true)
      ->select('*')
      ->from('#_ext_freechat_reactions')
      ->where('post_id = ' . $postId)
      ->where('user_id = ' . $user->id)
      ->loadObject();
    
    if ($existing) {
      if ($existing->type == $type) {
        // Remove reaction
        $db->delete('#_ext_freechat_reactions', ['id' => $existing->id]);
        echo json_encode(['success' => true, 'action' => 'removed']);
      } else {
        // Update reaction
        $db->update('#_ext_freechat_reactions', ['type' => $type], ['id' => $existing->id]);
        echo json_encode(['success' => true, 'action' => 'changed']);
      }
    } else {
      // Add reaction
      $db->insert('#_ext_freechat_reactions', [
        'post_id' => $postId,
        'user_id' => $user->id,
        'type' => $type,
        'created_at' => date('Y-m-d H:i:s')
      ]);
      echo json_encode(['success' => true, 'action' => 'added']);
    }
  }
  
  /**
   * Report post
   */
  public function report()
  {
    $user = User::getInstance();
    
    if (!$user->id) {
      Application::redirect('index.php?option=users&view=login&return=' . urlencode(Application::getUri()));
    }
    
    $postId = $this->input->getInt('post_id', 0);
    $reason = $this->input->getString('reason', '');
    $details = $this->input->getString('details', '');
    
    if (!$postId || empty($reason)) {
      Application::enqueueMessage(Language::translate('COM_FREECHAT_ERROR_INVALID_INPUT'), 'error');
      Application::redirect('index.php?option=freechat');
    }
    
    $db = Database::getInstance();
    
    $post = $db->getQuery(true)
      ->select('*')
      ->from('#_ext_freechat_posts')
      ->where('id = ' . $postId)
      ->loadObject();
    
    if (!$post) {
      Application::enqueueMessage(Language::translate('COM_FREECHAT_POST_NOT_FOUND'), 'error');
      Application::redirect('index.php?option=freechat');
    }
    
    $db->insert('#_ext_freechat_reports', [
      'type' => 'post',
      'item_id' => $postId,
      'reporter_id' => $user->id,
      'reason' => $reason,
      'details' => $details,
      'status' => 'pending',
      'created_at' => date('Y-m-d H:i:s')
    ]);
    
    Application::enqueueMessage(Language::translate('COM_FREECHAT_REPORT_SUBMITTED'), 'success');
    Application::redirect('index.php?option=freechat&view=topics&task=view&id=' . $post->topic_id);
  }
  
  private function processContent($content)
  {
    $html = htmlspecialchars($content);
    $html = nl2br($html);
    return $html;
  }
  
  private function notifySubscribers($topicId, $postId, $authorId)
  {
    $db = Database::getInstance();
    
    // Get subscribers excluding the author
    $subscribers = $db->getQuery(true)
      ->select('user_id')
      ->from('#_ext_freechat_subscriptions')
      ->where('type = ' . $db->quote('topic'))
      ->where('item_id = ' . $topicId)
      ->where('user_id != ' . $authorId)
      ->loadObjectList();
    
    foreach ($subscribers as $sub) {
      // Create in-app notification
      $db->insert('#_ext_freechat_notifications', [
        'user_id' => $sub->user_id,
        'type' => 'reply',
        'item_id' => $postId,
        'message_key' => 'reply',
        'created_at' => date('Y-m-d H:i:s')
      ]);
    }
  }
}
