-- Freechat Extension Install Script
-- Version: 1.0.0
-- Date: 2025-01-06

-- Spaces table
CREATE TABLE IF NOT EXISTS `#__ext_freechat_spaces` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `title` VARCHAR(255) NOT NULL,
  `slug` VARCHAR(255) NOT NULL UNIQUE,
  `description` TEXT,
  `ordering` INT UNSIGNED DEFAULT 0,
  `state` TINYINT(1) DEFAULT 1,
  `created_at` DATETIME NOT NULL,
  `created_by` INT UNSIGNED NOT NULL,
  `modified_at` DATETIME,
  `modified_by` INT UNSIGNED,
  INDEX `idx_space_ordering` (`ordering`),
  INDEX `idx_space_state` (`state`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Categories table
CREATE TABLE IF NOT EXISTS `#__ext_freechat_categories` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `space_id` INT UNSIGNED NOT NULL,
  `parent_id` INT UNSIGNED DEFAULT 0,
  `title` VARCHAR(255) NOT NULL,
  `slug` VARCHAR(255) NOT NULL,
  `description` TEXT,
  `threading_depth` TINYINT(1) DEFAULT 3,
  `moderation_model` ENUM('open','premod','postmod') DEFAULT 'open',
  `allow_tags` TINYINT(1) DEFAULT 1,
  `allow_revisions` TINYINT(1) DEFAULT 1,
  `ordering` INT UNSIGNED DEFAULT 0,
  `state` TINYINT(1) DEFAULT 1,
  `created_at` DATETIME NOT NULL,
  `created_by` INT UNSIGNED NOT NULL,
  `modified_at` DATETIME,
  `modified_by` INT UNSIGNED,
  INDEX `idx_category_space_id` (`space_id`),
  INDEX `idx_category_parent_id` (`parent_id`),
  INDEX `idx_category_ordering` (`ordering`),
  INDEX `idx_category_state` (`state`),
  FOREIGN KEY (`space_id`) REFERENCES `#__ext_freechat_spaces`(`id`) ON DELETE
CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Forums table
CREATE TABLE IF NOT EXISTS `#__ext_freechat_forums` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `category_id` INT UNSIGNED NOT NULL,
  `title` VARCHAR(255) NOT NULL,
  `slug` VARCHAR(255) NOT NULL,
  `description` TEXT,
  `override_category_settings` TINYINT(1) DEFAULT 0,
  `threading_depth` TINYINT(1) DEFAULT NULL,
  `moderation_model` ENUM('open','premod','postmod') DEFAULT NULL,
  `allow_tags` TINYINT(1) DEFAULT NULL,
  `allow_revisions` TINYINT(1) DEFAULT NULL,
  `default_view_role_id` INT UNSIGNED DEFAULT NULL,
  `default_post_role_id` INT UNSIGNED DEFAULT NULL,
  `ordering` INT UNSIGNED DEFAULT 0,
  `state` TINYINT(1) DEFAULT 1,
  `created_at` DATETIME NOT NULL,
  `created_by` INT UNSIGNED NOT NULL,
  `modified_at` DATETIME,
  `modified_by` INT UNSIGNED,
  INDEX `idx_forum_category_id` (`category_id`),
  INDEX `idx_forum_ordering` (`ordering`),
  INDEX `idx_forum_state` (`state`),
  FOREIGN KEY (`category_id`) REFERENCES `#__ext_freechat_categories`(`id`) ON
DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Topics table
CREATE TABLE IF NOT EXISTS `#__ext_freechat_topics` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `forum_id` INT UNSIGNED NOT NULL,
  `first_post_id` INT UNSIGNED NOT NULL,
  `title` VARCHAR(255) NOT NULL,
  `slug` VARCHAR(255) NOT NULL,
  `type` ENUM('normal','sticky','announcement','merged') DEFAULT 'normal',
  `state` ENUM('open','locked','hidden') DEFAULT 'open',
  `view_count` INT UNSIGNED DEFAULT 0,
  `reply_count` INT UNSIGNED DEFAULT 0,
  `last_post_id` INT UNSIGNED DEFAULT NULL,
  `last_post_at` DATETIME DEFAULT NULL,
  `last_post_by` INT UNSIGNED DEFAULT NULL,
  `is_private` TINYINT(1) DEFAULT 0,
  `created_at` DATETIME NOT NULL,
  `created_by` INT UNSIGNED NOT NULL,
  `modified_at` DATETIME,
  `modified_by` INT UNSIGNED,
  INDEX `idx_topic_forum_id` (`forum_id`),
  INDEX `idx_topic_created_by` (`created_by`),
  INDEX `idx_topic_last_post_at` (`last_post_at`),
  INDEX `idx_topic_type_state` (`type`,`state`),
  INDEX `idx_topic_created_at` (`created_at`),
  FOREIGN KEY (`forum_id`) REFERENCES `#__ext_freechat_forums`(`id`) ON DELETE
CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Posts table
CREATE TABLE IF NOT EXISTS `#__ext_freechat_posts` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `topic_id` INT UNSIGNED NOT NULL,
  `parent_id` INT UNSIGNED DEFAULT 0,
  `author_id` INT UNSIGNED NOT NULL,
  `content` LONGTEXT NOT NULL,
  `content_html` LONGTEXT NOT NULL,
  `state` ENUM('published','hidden','soft_deleted') DEFAULT 'published',
  `is_first_post` TINYINT(1) DEFAULT 0,
  `created_at` DATETIME NOT NULL,
  `modified_at` DATETIME DEFAULT NULL,
  `modified_by` INT UNSIGNED DEFAULT NULL,
  `ip_address` VARCHAR(45) DEFAULT NULL,
  INDEX `idx_post_topic_id` (`topic_id`),
  INDEX `idx_post_parent_id` (`parent_id`),
  INDEX `idx_post_author_id` (`author_id`),
  INDEX `idx_post_created_at` (`created_at`),
  INDEX `idx_post_state` (`state`),
  FOREIGN KEY (`topic_id`) REFERENCES `#__ext_freechat_topics`(`id`) ON DELETE
CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Revisions table
CREATE TABLE IF NOT EXISTS `#__ext_freechat_revisions` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `post_id` INT UNSIGNED NOT NULL,
  `content` LONGTEXT NOT NULL,
  `content_html` LONGTEXT NOT NULL,
  `created_at` DATETIME NOT NULL,
  `created_by` INT UNSIGNED NOT NULL,
  INDEX `idx_revision_post_id` (`post_id`),
  INDEX `idx_revision_created_at` (`created_at`),
  FOREIGN KEY (`post_id`) REFERENCES `#__ext_freechat_posts`(`id`) ON DELETE
CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Reactions table
CREATE TABLE IF NOT EXISTS `#__ext_freechat_reactions` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `post_id` INT UNSIGNED NOT NULL,
  `user_id` INT UNSIGNED NOT NULL,
  `type` ENUM('like','dislike','love','laugh') DEFAULT 'like',
  `created_at` DATETIME NOT NULL,
  UNIQUE KEY `uk_reaction_post_user` (`post_id`,`user_id`),
  INDEX `idx_reaction_post_id` (`post_id`),
  INDEX `idx_reaction_user_id` (`user_id`),
  INDEX `idx_reaction_type` (`type`),
  FOREIGN KEY (`post_id`) REFERENCES `#__ext_freechat_posts`(`id`) ON DELETE
CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Attachments table
CREATE TABLE IF NOT EXISTS `#__ext_freechat_attachments` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `post_id` INT UNSIGNED NOT NULL,
  `file_name` VARCHAR(255) NOT NULL,
  `file_path` VARCHAR(512) NOT NULL,
  `file_size` INT UNSIGNED NOT NULL,
  `mime_type` VARCHAR(127) NOT NULL,
  `is_inline` TINYINT(1) DEFAULT 0,
  `download_count` INT UNSIGNED DEFAULT 0,
  `created_at` DATETIME NOT NULL,
  `created_by` INT UNSIGNED NOT NULL,
  INDEX `idx_attachment_post_id` (`post_id`),
  INDEX `idx_attachment_created_by` (`created_by`),
  FOREIGN KEY (`post_id`) REFERENCES `#__ext_freechat_posts`(`id`) ON DELETE
CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Reports table
CREATE TABLE IF NOT EXISTS `#__ext_freechat_reports` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `type` ENUM('post','topic','user') NOT NULL,
  `item_id` INT UNSIGNED NOT NULL,
  `reporter_id` INT UNSIGNED NOT NULL,
  `reason` VARCHAR(255) NOT NULL,
  `details` TEXT,
  `status` ENUM('pending','reviewed','dismissed','resolved') DEFAULT 'pending',
  `reviewer_id` INT UNSIGNED DEFAULT NULL,
  `reviewed_at` DATETIME DEFAULT NULL,
  `created_at` DATETIME NOT NULL,
  INDEX `idx_report_type_item` (`type`,`item_id`),
  INDEX `idx_report_reporter_id` (`reporter_id`),
  INDEX `idx_report_status` (`status`),
  INDEX `idx_report_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Subscriptions table
CREATE TABLE IF NOT EXISTS `#__ext_freechat_subscriptions` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT UNSIGNED NOT NULL,
  `type` ENUM('topic','forum') NOT NULL,
  `item_id` INT UNSIGNED NOT NULL,
  `notify_on` SET('reply','mention','quote') DEFAULT 'reply,mention,quote',
  `email_digest` ENUM('none','daily','weekly') DEFAULT 'none',
  `created_at` DATETIME NOT NULL,
  UNIQUE KEY `uk_subscription_user_item` (`user_id`,`type`,`item_id`),
  INDEX `idx_subscription_user_id` (`user_id`),
  INDEX `idx_subscription_type_item` (`type`,`item_id`),
  INDEX `idx_subscription_email_digest` (`email_digest`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Notifications table
CREATE TABLE IF NOT EXISTS `#__ext_freechat_notifications` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT UNSIGNED NOT NULL,
  `type` ENUM('reply','mention','quote','subscription') NOT NULL,
  `item_id` INT UNSIGNED NOT NULL,
  `message_key` VARCHAR(127) NOT NULL,
  `is_read` TINYINT(1) DEFAULT 0,
  `read_at` DATETIME DEFAULT NULL,
  `created_at` DATETIME NOT NULL,
  INDEX `idx_notification_user_id` (`user_id`),
  INDEX `idx_notification_is_read` (`is_read`),
  INDEX `idx_notification_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Default data: Create initial space, category, and forum
INSERT INTO `#__ext_freechat_spaces` (`title`, `slug`, `description`,
`ordering`, `state`, `created_at`, `created_by`)
VALUES ('Community', 'community', 'General community discussion area', 1, 1,
NOW(), 1);

INSERT INTO `#__ext_freechat_categories` (`space_id`, `parent_id`, `title`,
`slug`, `description`, `threading_depth`, `moderation_model`, `allow_tags`,
`allow_revisions`, `ordering`, `state`, `created_at`, `created_by`)
VALUES (1, 0, 'General', 'general', 'General discussion category', 3, 'open', 1,
1, 1, 1, NOW(), 1);

INSERT INTO `#__ext_freechat_forums` (`category_id`, `title`, `slug`,
`description`, `ordering`, `state`, `created_at`, `created_by`)
VALUES (1, 'Announcements', 'announcements', 'Official announcements and sticky
topics', 1, 1, NOW(), 1);

INSERT INTO `#__ext_freechat_forums` (`category_id`, `title`, `slug`,
`description`, `ordering`, `state`, `created_at`, `created_by`)
VALUES (1, 'General Discussion', 'general-discussion', 'Open discussion on any topic', 2, 1, NOW(), 1);

-- Update first_post_id for topics after posts are created
-- This will be handled by the application logic
