<?php
/**
 * Freechat Extension - Site View - Single Topic View
 */

defined('_FFEXEC') or die;

use Freeflow\Core\User;

$topic = $this->topic;
$posts = $this->posts;
$pagination = $this->pagination;
$user = User::getInstance();
?>
<div class="freechat-container">
  <nav aria-label="breadcrumb" class="mb-3">
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="index.php?option=freechat"><?php echo Language::translate('COM_FREECHAT_FORUM_INDEX'); ?></a></li>
      <li class="breadcrumb-item"><a href="index.php?option=freechat&view=topics&forum_id=<?php echo $topic->forum_id; ?>"><?php echo htmlspecialchars($topic->forum_title); ?></a></li>
      <li class="breadcrumb-item active"><?php echo htmlspecialchars($topic->title); ?></li>
    </ol>
  </nav>

  <div class="d-flex justify-content-between align-items-center mb-3">
    <h1 class="h4 mb-0">
      <?php if ($topic->type == 'sticky'): ?>
        <i class="fa-solid fa-thumbtack text-warning me-2"></i>
      <?php elseif ($topic->type == 'announcement'): ?>
        <i class="fa-solid fa-bullhorn text-info me-2"></i>
      <?php endif; ?>
      
      <?php if ($topic->state == 'locked'): ?>
        <i class="fa-solid fa-lock text-danger me-2"></i>
      <?php endif; ?>
      
      <?php echo htmlspecialchars($topic->title); ?>
    </h1>
    
    <div>
      <?php if ($user->id): ?>
        <button class="btn btn-sm <?php echo $topic->is_subscribed ? 'btn-warning' : 'btn-outline-warning'; ?> subscription-toggle" data-topic-id="<?php echo $topic->id; ?>">
          <i class="fa-solid <?php echo $topic->is_subscribed ? 'fa-bell' : 'fa-regular fa-bell'; ?> me-1"></i>
          <?php echo $topic->is_subscribed ? Language::translate('COM_FREECHAT_SUBSCRIPTION_SUBSCRIBED') : Language::translate('COM_FREECHAT_SUBSCRIPTION_UNSUBSCRIBED'); ?>
        </button>
      <?php endif; ?>
      
      <?php if ($topic->state != 'locked' && $user->can('freechat.posts.create')): ?>
        <a href="index.php?option=freechat&view=posts&task=reply&topic_id=<?php echo $topic->id; ?>" class="btn btn-primary btn-sm">
          <i class="fa-solid fa-reply me-1"></i>
          <?php echo Language::translate('COM_FREECHAT_POST_REPLY'); ?>
        </a>
      <?php endif; ?>
    </div>
  </div>

  <div class="card mb-3">
    <div class="card-body">
      <div class="row">
        <div class="col-md-6">
          <small class="text-muted">
            <?php echo Language::translate('COM_FREECHAT_TOPICS'); ?>: <?php echo $topic->reply_count + 1; ?> |
            <?php echo Language::translate('COM_FREECHAT_TOPIC_VIEW_COUNT'); ?>: <?php echo $topic->view_count; ?>
          </small>
        </div>
        <div class="col-md-6 text-md-end">
          <small class="text-muted">
            <?php echo Language::translate('COM_FREECHAT_TOPIC_BY'); ?> <?php echo htmlspecialchars($topic->author_name); ?>
          </small>
        </div>
      </div>
    </div>
  </div>

  <?php foreach ($posts as $post): ?>
    <div class="card mb-3 post-item" id="post-<?php echo $post->id; ?>">
      <div class="card-header bg-light d-flex justify-content-between align-items-center">
        <div>
          <strong><?php echo htmlspecialchars($post->author_name); ?></strong>
          <small class="text-muted ms-2">
            <?php echo date('M d, Y H:i', strtotime($post->created_at)); ?>
          </small>
          <?php if ($post->modified_at): ?>
            <small class="text-muted">
              (<?php echo Language::translate('COM_FREECHAT_POST_EDITED'); ?> <?php echo date('M d, Y H:i', strtotime($post->modified_at)); ?>)
            </small>
          <?php endif; ?>
        </div>
        <div>
          <a href="#post-<?php echo $post->id; ?>" class="btn btn-sm btn-outline-secondary">
            <i class="fa-solid fa-link"></i>
          </a>
        </div>
      </div>
      <div class="card-body">
        <div class="post-content mb-3">
          <?php echo $post->content_html; ?>
        </div>
        
        <?php if (!empty($post->reactions)): ?>
          <div class="post-reactions mb-3">
            <?php foreach ($post->reactions as $reaction): ?>
              <span class="badge bg-secondary me-1">
                <i class="fa-solid <?php
                  switch($reaction->type) {
                    case 'like': echo 'fa-thumbs-up'; break;
                    case 'love': echo 'fa-heart'; break;
                    case 'laugh': echo 'fa-face-laugh'; break;
                    case 'dislike': echo 'fa-thumbs-down'; break;
                  }
                ?> me-1"></i>
                <?php echo $reaction->count; ?>
              </span>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
        
        <div class="post-actions d-flex gap-2">
          <?php if ($user->id): ?>
            <?php if ($user->can('freechat.reactions.use')): ?>
              <div class="btn-group btn-group-sm">
                <button class="btn btn-outline-secondary reaction-btn" data-post-id="<?php echo $post->id; ?>" data-type="like">
                  <i class="fa-regular fa-thumbs-up"></i>
                </button>
                <button class="btn btn-outline-secondary reaction-btn" data-post-id="<?php echo $post->id; ?>" data-type="love">
                  <i class="fa-regular fa-heart"></i>
                </button>
                <button class="btn btn-outline-secondary reaction-btn" data-post-id="<?php echo $post->id; ?>" data-type="laugh">
                  <i class="fa-regular fa-face-laugh"></i>
                </button>
              </div>
            <?php endif; ?>
            
            <a href="index.php?option=freechat&view=posts&task=reply&topic_id=<?php echo $topic->id; ?>&quote_id=<?php echo $post->id; ?>" class="btn btn-sm btn-outline-secondary">
              <i class="fa-solid fa-quote-right me-1"></i>
              <?php echo Language::translate('COM_FREECHAT_POST_QUOTE'); ?>
            </a>
            
            <?php if ($user->id == $post->author_id && $user->can('freechat.posts.edit')): ?>
              <a href="index.php?option=freechat&view=posts&task=edit&id=<?php echo $post->id; ?>" class="btn btn-sm btn-outline-secondary">
                <i class="fa-solid fa-pencil me-1"></i>
                <?php echo Language::translate('COM_FREECHAT_POST_EDIT'); ?>
              </a>
            <?php endif; ?>
            
            <button class="btn btn-sm btn-outline-danger report-btn" data-post-id="<?php echo $post->id; ?>">
              <i class="fa-solid fa-flag me-1"></i>
              <?php echo Language::translate('COM_FREECHAT_POST_REPORT'); ?>
            </button>
          <?php endif; ?>
        </div>
      </div>
    </div>
  <?php endforeach; ?>

  <?php if ($topic->state != 'locked' && $user->can('freechat.posts.create')): ?>
    <div class="card mb-3">
      <div class="card-header">
        <h5 class="mb-0"><?php echo Language::translate('COM_FREECHAT_POST_QUICK_REPLY'); ?></h5>
      </div>
      <div class="card-body">
        <form action="index.php?option=freechat&view=posts&task=save" method="post">
          <input type="hidden" name="topic_id" value="<?php echo $topic->id; ?>">
          
          <div class="mb-3">
            <textarea class="form-control" name="content" rows="5" required placeholder="<?php echo Language::translate('COM_FREECHAT_POST_REPLY'); ?>..."></textarea>
          </div>
          
          <button type="submit" class="btn btn-primary">
            <i class="fa-solid fa-paper-plane me-1"></i>
            <?php echo Language::translate('COM_FREECHAT_POST_REPLY'); ?>
          </button>
        </form>
      </div>
    </div>
  <?php endif; ?>

  <?php if ($pagination['pages'] > 1): ?>
    <nav class="mt-3">
      <ul class="pagination justify-content-center mb-0">
        <?php if ($pagination['page'] > 1): ?>
          <li class="page-item">
            <a class="page-link" href="index.php?option=freechat&view=topics&task=view&id=<?php echo $topic->id; ?>&page=<?php echo $pagination['page'] - 1; ?>">
              <?php echo Language::translate('COM_FREECHAT_PAGINATION_PREVIOUS'); ?>
            </a>
          </li>
        <?php endif; ?>
        
        <?php for ($i = 1; $i <= $pagination['pages']; $i++): ?>
          <li class="page-item <?php echo $i == $pagination['page'] ? 'active' : ''; ?>">
            <a class="page-link" href="index.php?option=freechat&view=topics&task=view&id=<?php echo $topic->id; ?>&page=<?php echo $i; ?>">
              <?php echo $i; ?>
            </a>
          </li>
        <?php endfor; ?>
        
        <?php if ($pagination['page'] < $pagination['pages']): ?>
          <li class="page-item">
            <a class="page-link" href="index.php?option=freechat&view=topics&task=view&id=<?php echo $topic->id; ?>&page=<?php echo $pagination['page'] + 1; ?>">
              <?php echo Language::translate('COM_FREECHAT_PAGINATION_NEXT'); ?>
            </a>
          </li>
        <?php endif; ?>
      </ul>
    </nav>
  <?php endif; ?>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
  // Subscription toggle
  document.querySelectorAll('.subscription-toggle').forEach(function(btn) {
    btn.addEventListener('click', function() {
      var topicId = this.dataset.topicId;
      fetch('index.php?option=freechat&view=topics&task=toggleSubscription&topic_id=' + topicId)
        .then(function(response) { return response.json(); })
        .then(function(data) {
          if (data.success) {
            var icon = btn.querySelector('i');
            if (data.subscribed) {
              btn.classList.remove('btn-outline-warning');
              btn.classList.add('btn-warning');
              icon.classList.remove('fa-regular');
              icon.classList.add('fa-solid');
              btn.childNodes[2].textContent = ' ' + '<?php echo Language::translate('COM_FREECHAT_SUBSCRIPTION_SUBSCRIBED'); ?>';
            } else {
              btn.classList.remove('btn-warning');
              btn.classList.add('btn-outline-warning');
              icon.classList.remove('fa-solid');
              icon.classList.add('fa-regular');
              btn.childNodes[2].textContent = ' ' + '<?php echo Language::translate('COM_FREECHAT_SUBSCRIPTION_UNSUBSCRIBED'); ?>';
            }
          }
        });
    });
  });

  // Reaction buttons
  document.querySelectorAll('.reaction-btn').forEach(function(btn) {
    btn.addEventListener('click', function() {
      var postId = this.dataset.postId;
      var type = this.dataset.type;
      fetch('index.php?option=freechat&view=posts&task=react&post_id=' + postId + '&type=' + type)
        .then(function(response) { return response.json(); })
        .then(function(data) {
          if (data.success) {
            // Could update UI here
          }
        });
    });
  });
});
</script>
