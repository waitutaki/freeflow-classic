<?php
/**
 * Freechat Extension - Admin View - Topics List
 */

defined('_FFEXEC') or die;
?>
<div class="container-fluid">
  <div class="row mb-3">
    <div class="col">
      <h1 class="h3 mb-0">
        <i class="fa-solid fa-comment-dots me-2"></i>
        <?php echo Language::translate('COM_FREECHAT_TOPICS'); ?>
      </h1>
    </div>
  </div>

  <div class="card mb-3">
    <div class="card-body">
      <form action="index.php?option=freechat&view=topics" method="get" class="row g-3">
        <input type="hidden" name="option" value="freechat">
        <input type="hidden" name="view" value="topics">
        
        <div class="col-md-3">
          <label for="forum_id" class="form-label"><?php echo Language::translate('COM_FREECHAT_FORUMS'); ?></label>
          <select class="form-select" id="forum_id" name="forum_id">
            <option value="">All forums</option>
            <?php foreach ($this->forums as $forum): ?>
              <option value="<?php echo $forum->id; ?>" <?php echo ($this->filters['forum_id'] ?? 0) == $forum->id ? 'selected' : ''; ?>>
                <?php echo htmlspecialchars($forum->title); ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>
        
        <div class="col-md-3">
          <label for="state" class="form-label"><?php echo Language::translate('COM_FREECHAT_TOPIC_STATE'); ?></label>
          <select class="form-select" id="state" name="state">
            <option value="">All states</option>
            <option value="open" <?php echo ($this->filters['state'] ?? '') == 'open' ? 'selected' : ''; ?>>
              <?php echo Language::translate('COM_FREECHAT_TOPIC_OPEN'); ?>
            </option>
            <option value="locked" <?php echo ($this->filters['state'] ?? '') == 'locked' ? 'selected' : ''; ?>>
              <?php echo Language::translate('COM_FREECHAT_TOPIC_LOCKED'); ?>
            </option>
            <option value="hidden" <?php echo ($this->filters['state'] ?? '') == 'hidden' ? 'selected' : ''; ?>>
              <?php echo Language::translate('COM_FREECHAT_TOPIC_HIDDEN'); ?>
            </option>
          </select>
        </div>
        
        <div class="col-md-3">
          <label for="type" class="form-label"><?php echo Language::translate('COM_FREECHAT_TOPIC_TYPE'); ?></label>
          <select class="form-select" id="type" name="type">
            <option value="">All types</option>
            <option value="normal" <?php echo ($this->filters['type'] ?? '') == 'normal' ? 'selected' : ''; ?>>
              <?php echo Language::translate('COM_FREECHAT_TOPIC_NORMAL'); ?>
            </option>
            <option value="sticky" <?php echo ($this->filters['type'] ?? '') == 'sticky' ? 'selected' : ''; ?>>
              <?php echo Language::translate('COM_FREECHAT_TOPIC_STICKY'); ?>
            </option>
            <option value="announcement" <?php echo ($this->filters['type'] ?? '') == 'announcement' ? 'selected' : ''; ?>>
              <?php echo Language::translate('COM_FREECHAT_TOPIC_ANNOUNCEMENT'); ?>
            </option>
          </select>
        </div>
        
        <div class="col-md-3 d-flex align-items-end">
          <button type="submit" class="btn btn-primary w-100">
            <i class="fa-solid fa-filter me-1"></i>
            <?php echo Language::translate('COM_FREECHAT_SEARCH'); ?>
          </button>
        </div>
      </form>
    </div>
  </div>

  <div class="card">
    <div class="card-body">
      <?php if (empty($this->topics)): ?>
        <div class="alert alert-info">
          <?php echo Language::translate('COM_FREECHAT_TOPIC_NO_TOPICS'); ?>
        </div>
      <?php else: ?>
        <div class="table-responsive">
          <table class="table table-hover align-middle">
            <thead>
              <tr>
                <th><?php echo Language::translate('COM_FREECHAT_TOPICS'); ?></th>
                <th><?php echo Language::translate('COM_FREECHAT_FORUMS'); ?></th>
                <th><?php echo Language::translate('COM_FREECHAT_POSTS'); ?></th>
                <th><?php echo Language::translate('COM_FREECHAT_TOPIC_VIEW_COUNT'); ?></th>
                <th><?php echo Language::translate('COM_FREECHAT_TOPIC_BY'); ?></th>
                <th class="text-center"><?php echo Language::translate('COM_FREECHAT_MODERATION'); ?></th>
                <th class="text-end"><?php echo Language::translate('COM_FREECHAT_EDIT'); ?></th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($this->topics as $topic): ?>
                <tr>
                  <td>
                    <a href="index.php?option=freechat&view=topics&task=view&id=<?php echo $topic->id; ?>">
                      <strong><?php echo htmlspecialchars($topic->title); ?></strong>
                    </a>
                    <br>
                    <small>
                      <?php if ($topic->type == 'sticky'): ?>
                        <span class="badge bg-warning text-dark"><?php echo Language::translate('COM_FREECHAT_TOPIC_STICKY'); ?></span>
                      <?php elseif ($topic->type == 'announcement'): ?>
                        <span class="badge bg-info"><?php echo Language::translate('COM_FREECHAT_TOPIC_ANNOUNCEMENT'); ?></span>
                      <?php endif; ?>
                      
                      <?php if ($topic->state == 'locked'): ?>
                        <span class="badge bg-danger"><?php echo Language::translate('COM_FREECHAT_TOPIC_LOCKED'); ?></span>
                      <?php elseif ($topic->state == 'hidden'): ?>
                        <span class="badge bg-secondary"><?php echo Language::translate('COM_FREECHAT_TOPIC_HIDDEN'); ?></span>
                      <?php endif; ?>
                      
                      <?php if ($topic->is_private): ?>
                        <span class="badge bg-dark"><?php echo Language::translate('COM_FREECHAT_TOPIC_PRIVATE'); ?></span>
                      <?php endif; ?>
                    </small>
                  </td>
                  <td><?php echo htmlspecialchars($topic->forum_title); ?></td>
                  <td><?php echo $topic->reply_count; ?></td>
                  <td><?php echo $topic->view_count; ?></td>
                  <td><?php echo htmlspecialchars($topic->author_name); ?></td>
                  <td class="text-center">
                    <button class="btn btn-sm btn-link toggle-sticky"
                            data-id="<?php echo $topic->id; ?>"
                            data-sticky="<?php echo $topic->type == 'sticky' ? 1 : 0; ?>"
                            data-url="index.php?option=freechat&view=topics&task=toggleSticky">
                      <i class="fa-solid <?php echo $topic->type == 'sticky' ? 'fa-thumbtack text-warning' : 'fa-regular fa-thumbtack'; ?> fa-lg"></i>
                    </button>
                    <button class="btn btn-sm btn-link toggle-locked"
                            data-id="<?php echo $topic->id; ?>"
                            data-locked="<?php echo $topic->state == 'locked' ? 1 : 0; ?>"
                            data-url="index.php?option=freechat&view=topics&task=toggleLocked">
                      <i class="fa-solid <?php echo $topic->state == 'locked' ? 'fa-lock text-danger' : 'fa-lock-open text-success'; ?> fa-lg"></i>
                    </button>
                  </td>
                  <td class="text-end">
                    <a href="index.php?option=freechat&view=topics&task=view&id=<?php echo $topic->id; ?>" class="btn btn-sm btn-outline-primary">
                      <i class="fa-solid fa-eye"></i>
                    </a>
                    <?php if ($topic->state == 'hidden'): ?>
                      <a href="index.php?option=freechat&view=topics&task=show&id=<?php echo $topic->id; ?>" class="btn btn-sm btn-outline-success">
                        <i class="fa-solid fa-eye-slash"></i>
                      </a>
                    <?php else: ?>
                      <a href="index.php?option=freechat&view=topics&task=hide&id=<?php echo $topic->id; ?>" class="btn btn-sm btn-outline-warning">
                        <i class="fa-solid fa-eye-slash"></i>
                      </a>
                    <?php endif; ?>
                    <a href="index.php?option=freechat&view=topics&task=delete&id=<?php echo $topic->id; ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('<?php echo Language::translate('COM_FREECHAT_CONFIRM_DELETE'); ?>')">
                      <i class="fa-solid fa-trash"></i>
                    </a>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
  document.querySelectorAll('.toggle-sticky').forEach(function(btn) {
    btn.addEventListener('click', function(e) {
      e.preventDefault();
      var id = this.dataset.id;
      var isSticky = parseInt(this.dataset.sticky);
      var newSticky = isSticky ? 0 : 1;
      var url = this.dataset.url + '&id=' + id + '&sticky=' + newSticky;
      
      fetch(url)
        .then(function(response) { return response.json(); })
        .then(function(data) {
          if (data.success) {
            var icon = btn.querySelector('i');
            icon.className = 'fa-solid ' + (newSticky ? 'fa-thumbtack text-warning' : 'fa-regular fa-thumbtack') + ' fa-lg';
            btn.dataset.sticky = newSticky;
          }
        });
    });
  });
  
  document.querySelectorAll('.toggle-locked').forEach(function(btn) {
    btn.addEventListener('click', function(e) {
      e.preventDefault();
      var id = this.dataset.id;
      var isLocked = parseInt(this.dataset.locked);
      var newLocked = isLocked ? 0 : 1;
      var url = this.dataset.url + '&id=' + id + '&locked=' + newLocked;
      
      fetch(url)
        .then(function(response) { return response.json(); })
        .then(function(data) {
          if (data.success) {
            var icon = btn.querySelector('i');
            icon.className = 'fa-solid ' + (newLocked ? 'fa-lock text-danger' : 'fa-lock-open text-success') + ' fa-lg';
            btn.dataset.locked = newLocked;
          }
        });
    });
  });
});
</script>
