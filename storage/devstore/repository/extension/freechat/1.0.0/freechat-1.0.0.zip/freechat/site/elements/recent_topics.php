<?php
/**
 * Freechat Extension - Recent Topics Element
 * Displays recent forum topics
 */

defined('_FFEXEC') or die;

use Freeflow\Core\Database;
use Freeflow\Core\Language;

$db = Database::getInstance();

$limit = $params->get('limit', 5);
$forumId = $params->get('forum_id', 0);

$query = $db->getQuery(true)
  ->select('t.*')
  ->select('f.title as forum_title')
  ->select('u.name as author_name')
  ->from('#_ext_freechat_topics t')
  ->leftJoin('#_ext_freechat_forums f ON t.forum_id = f.id')
  ->leftJoin('#_users u ON t.created_by = u.id')
  ->where('t.state IN (\'open\',\'locked\')')
  ->where('t.is_private = 0');

if ($forumId) {
  $query->where('t.forum_id = ' . $forumId);
}

$query->order('t.last_post_at DESC')
  ->setLimit($limit);

$topics = $db->setQuery($query)->loadObjectList();
?>
<div class="freechat-element freechat-recent-topics">
  <div class="card">
    <div class="card-header">
      <h6 class="mb-0">
        <i class="fa-solid fa-clock-rotate-left me-2"></i>
        <?php echo Language::translate('COM_FREECHAT_ELEMENT_RECENT_TOPICS'); ?>
      </h6>
    </div>
    <div class="card-body p-0">
      <?php if (empty($topics)): ?>
        <div class="p-3 text-center text-muted small">
          <?php echo Language::translate('COM_FREECHAT_NOT_FOUND'); ?>
        </div>
      <?php else: ?>
        <ul class="list-group list-group-flush">
          <?php foreach ($topics as $topic): ?>
            <li class="list-group-item">
              <a href="index.php?option=freechat&view=topics&task=view&id=<?php echo $topic->id; ?>" class="text-decoration-none">
                <div class="fw-bold"><?php echo htmlspecialchars($topic->title); ?></div>
                <small class="text-muted">
                  <?php echo htmlspecialchars($topic->author_name); ?> -
                  <?php echo date('M d, H:i', strtotime($topic->last_post_at)); ?>
                </small>
              </a>
            </li>
          <?php endforeach; ?>
        </ul>
      <?php endif; ?>
    </div>
  </div>
</div>
