<?php
/**
 * Freechat Extension - Settings Controller
 * Admin controller for extension settings
 */

namespace Freeflow\Extension\Freechat\Admin;

defined('_FFEXEC') or die;

use Freeflow\Core\Controller;
use Freeflow\Core\Database;
use Freeflow\Core\Language;
use Freeflow\Core\Application;
use Freeflow\Core\Config;

class SettingsController extends Controller
{
  /**
   * Display settings form
   */
  public function display()
  {
    $this->checkPermission('freechat.manage');
    
    $db = Database::getInstance();
    
    // Get current settings from database
    $settings = [
      'default_moderation' => 'open',
      'allow_attachments' => 1,
      'max_attachment_size' => 5120,
      'email_notifications' => 1,
      'email_digest' => 'none'
    ];
    
    $configTable = '#__config';
    $tableExists = $db->getQuery(true)
      ->select('COUNT(*)')
      ->from('information_schema.tables')
      ->where('table_name = ' . $db->quote(str_replace('#_', $db->getPrefix(), $configTable)))
      ->loadResult();
    
    if ($tableExists) {
      foreach ($settings as $key => $default) {
        $value = $db->getQuery(true)
          ->select('value')
          ->from($configTable)
          ->where('key = ' . $db->quote('com_freechat_' . $key))
          ->loadResult();
        
        if ($value !== null) {
          $settings[$key] = $value;
        }
      }
    }
    
    $this->view->assign('settings', $settings);
    $this->view->setLayout('default');
    $this->view->display();
  }
  
  /**
   * Save settings
   */
  public function save()
  {
    $this->checkPermission('freechat.manage');
    
    $defaultModeration = $this->input->getString('default_moderation', 'open');
    $allowAttachments = $this->input->getInt('allow_attachments', 1);
    $maxAttachmentSize = $this->input->getInt('max_attachment_size', 5120);
    $emailNotifications = $this->input->getInt('email_notifications', 1);
    $emailDigest = $this->input->getString('email_digest', 'none');
    
    $db = Database::getInstance();
    
    $settings = [
      'com_freechat_default_moderation' => $defaultModeration,
      'com_freechat_allow_attachments' => $allowAttachments,
      'com_freechat_max_attachment_size' => $maxAttachmentSize,
      'com_freechat_email_notifications' => $emailNotifications,
      'com_freechat_email_digest' => $emailDigest
    ];
    
    foreach ($settings as $key => $value) {
      // Check if config exists
      $exists = $db->getQuery(true)
        ->select('COUNT(*)')
        ->from('#__config')
        ->where('key = ' . $db->quote($key))
        ->loadResult();
      
      if ($exists) {
        $db->update('#__config', ['value' => $value], ['key' => $key]);
      } else {
        $db->insert('#__config', ['key' => $key, 'value' => $value]);
      }
    }
    
    Application::enqueueMessage(Language::translate('COM_FREECHAT_CONFIG_SETTINGS_SAVED'), 'success');
    $this->redirect('index.php?option=freechat&view=settings');
  }
  
  /**
   * Get setting value
   */
  public function getSetting($key, $default = null)
  {
    $db = Database::getInstance();
    
    $value = $db->getQuery(true)
      ->select('value')
      ->from('#__config')
      ->where('key = ' . $db->quote('com_freechat_' . $key))
      ->loadResult();
    
    return $value !== null ? $value : $default;
  }
}
