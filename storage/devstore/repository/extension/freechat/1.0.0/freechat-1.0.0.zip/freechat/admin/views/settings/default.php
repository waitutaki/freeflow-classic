<?php
/**
 * Freechat Extension - Admin View - Settings
 */

defined('_FFEXEC') or die;

$settings = $this->settings;
?>
<div class="container-fluid">
  <div class="row mb-3">
    <div class="col">
      <h1 class="h3 mb-0">
        <i class="fa-solid fa-cog me-2"></i>
        <?php echo Language::translate('COM_FREECHAT_SETTINGS'); ?>
      </h1>
    </div>
  </div>

  <div class="card">
    <div class="card-body">
      <form action="index.php?option=freechat&view=settings&task=save" method="post">
        <h5 class="card-title mb-3"><?php echo Language::translate('COM_FREECHAT_CATEGORY_MODERATION'); ?></h5>
        
        <div class="row mb-3">
          <div class="col-md-6">
            <label for="default_moderation" class="form-label"><?php echo Language::translate('COM_FREECHAT_CONFIG_DEFAULT_MODERATION'); ?></label>
            <select class="form-select" id="default_moderation" name="default_moderation">
              <option value="open" <?php echo ($settings['default_moderation'] ?? 'open') == 'open' ? 'selected' : ''; ?>>
                <?php echo Language::translate('COM_FREECHAT_CONFIG_MODERATION_OPEN'); ?>
              </option>
              <option value="premod" <?php echo ($settings['default_moderation'] ?? 'open') == 'premod' ? 'selected' : ''; ?>>
                <?php echo Language::translate('COM_FREECHAT_CONFIG_MODERATION_PREMOD'); ?>
              </option>
              <option value="postmod" <?php echo ($settings['default_moderation'] ?? 'open') == 'postmod' ? 'selected' : ''; ?>>
                <?php echo Language::translate('COM_FREECHAT_CONFIG_MODERATION_POSTMOD'); ?>
              </option>
            </select>
            <small class="text-muted">Default moderation model for new categories</small>
          </div>
        </div>
        
        <hr class="my-4">
        
        <h5 class="card-title mb-3"><?php echo Language::translate('COM_FREECHAT_ATTACHMENT_ADD'); ?></h5>
        
        <div class="row mb-3">
          <div class="col-md-6">
            <div class="form-check form-switch mb-3">
              <input class="form-check-input" type="checkbox" id="allow_attachments" name="allow_attachments" value="1" <?php echo ($settings['allow_attachments'] ?? 1) == 1 ? 'checked' : ''; ?>>
              <label class="form-check-label" for="allow_attachments"><?php echo Language::translate('COM_FREECHAT_CONFIG_ALLOW_ATTACHMENTS'); ?></label>
            </div>
          </div>
        </div>
        
        <div class="row mb-3">
          <div class="col-md-4">
            <label for="max_attachment_size" class="form-label"><?php echo Language::translate('COM_FREECHAT_CONFIG_MAX_ATTACHMENT_SIZE'); ?></label>
            <div class="input-group">
              <input type="number" class="form-control" id="max_attachment_size" name="max_attachment_size" value="<?php echo $settings['max_attachment_size'] ?? 5120; ?>" min="0">
              <span class="input-group-text">KB</span>
            </div>
          </div>
        </div>
        
        <hr class="my-4">
        
        <h5 class="card-title mb-3"><?php echo Language::translate('COM_FREECHAT_NOTIFICATION_SETTINGS'); ?></h5>
        
        <div class="row mb-3">
          <div class="col-md-6">
            <div class="form-check form-switch mb-3">
              <input class="form-check-input" type="checkbox" id="email_notifications" name="email_notifications" value="1" <?php echo ($settings['email_notifications'] ?? 1) == 1 ? 'checked' : ''; ?>>
              <label class="form-check-label" for="email_notifications"><?php echo Language::translate('COM_FREECHAT_CONFIG_EMAIL_NOTIFICATIONS'); ?></label>
            </div>
          </div>
        </div>
        
        <div class="row mb-3">
          <div class="col-md-4">
            <label for="email_digest" class="form-label"><?php echo Language::translate('COM_FREECHAT_CONFIG_EMAIL_DIGEST'); ?></label>
            <select class="form-select" id="email_digest" name="email_digest">
              <option value="none" <?php echo ($settings['email_digest'] ?? 'none') == 'none' ? 'selected' : ''; ?>>
                <?php echo Language::translate('COM_FREECHAT_CONFIG_DIGEST_NONE'); ?>
              </option>
              <option value="daily" <?php echo ($settings['email_digest'] ?? 'none') == 'daily' ? 'selected' : ''; ?>>
                <?php echo Language::translate('COM_FREECHAT_CONFIG_DIGEST_DAILY'); ?>
              </option>
              <option value="weekly" <?php echo ($settings['email_digest'] ?? 'none') == 'weekly' ? 'selected' : ''; ?>>
                <?php echo Language::translate('COM_FREECHAT_CONFIG_DIGEST_WEEKLY'); ?>
              </option>
            </select>
          </div>
        </div>
        
        <div class="row">
          <div class="col">
            <button type="submit" class="btn btn-primary">
              <i class="fa-solid fa-check me-1"></i>
              <?php echo Language::translate('COM_FREECHAT_SAVE'); ?>
            </button>
          </div>
        </div>
      </form>
    </div>
  </div>
</div>
