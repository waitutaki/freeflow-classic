<?php
/**
 * Freechat Extension - Admin View - Reports List
 */

defined('_FFEXEC') or die;
?>
<div class="container-fluid">
  <div class="row mb-3">
    <div class="col">
      <h1 class="h3 mb-0">
        <i class="fa-solid fa-flag me-2"></i>
        <?php echo Language::translate('COM_FREECHAT_REPORTS'); ?>
      </h1>
    </div>
  </div>

  <div class="card mb-3">
    <div class="card-body">
      <form action="index.php?option=freechat&view=reports" method="get" class="row g-3">
        <input type="hidden" name="option" value="freechat">
        <input type="hidden" name="view" value="reports">
        
        <div class="col-md-4">
          <label for="status" class="form-label"><?php echo Language::translate('COM_FREECHAT_REPORT_STATUS_PENDING'); ?></label>
          <select class="form-select" id="status" name="status">
            <option value="">All statuses</option>
            <option value="pending" <?php echo ($this->filters['status'] ?? '') == 'pending' ? 'selected' : ''; ?>>
              <?php echo Language::translate('COM_FREECHAT_REPORT_STATUS_PENDING'); ?>
            </option>
            <option value="reviewed" <?php echo ($this->filters['status'] ?? '') == 'reviewed' ? 'selected' : ''; ?>>
              <?php echo Language::translate('COM_FREECHAT_REPORT_STATUS_REVIEWED'); ?>
            </option>
            <option value="dismissed" <?php echo ($this->filters['status'] ?? '') == 'dismissed' ? 'selected' : ''; ?>>
              <?php echo Language::translate('COM_FREECHAT_REPORT_STATUS_DISMISSED'); ?>
            </option>
            <option value="resolved" <?php echo ($this->filters['status'] ?? '') == 'resolved' ? 'selected' : ''; ?>>
              <?php echo Language::translate('COM_FREECHAT_REPORT_STATUS_RESOLVED'); ?>
            </option>
          </select>
        </div>
        
        <div class="col-md-4">
          <label for="type" class="form-label"><?php echo Language::translate('COM_FREECHAT_REPORT_NEW'); ?></label>
          <select class="form-select" id="type" name="type">
            <option value="">All types</option>
            <option value="post" <?php echo ($this->filters['type'] ?? '') == 'post' ? 'selected' : ''; ?>>
              <?php echo Language::translate('COM_FREECHAT_REPORT_POST'); ?>
            </option>
            <option value="topic" <?php echo ($this->filters['type'] ?? '') == 'topic' ? 'selected' : ''; ?>>
              <?php echo Language::translate('COM_FREECHAT_REPORT_TOPIC'); ?>
            </option>
            <option value="user" <?php echo ($this->filters['type'] ?? '') == 'user' ? 'selected' : ''; ?>>
              <?php echo Language::translate('COM_FREECHAT_REPORT_USER'); ?>
            </option>
          </select>
        </div>
        
        <div class="col-md-4 d-flex align-items-end">
          <button type="submit" class="btn btn-primary w-100">
            <i class="fa-solid fa-filter me-1"></i>
            <?php echo Language::translate('COM_FREECHAT_SEARCH'); ?>
          </button>
        </div>
      </form>
    </div>
  </div>

  <div class="card">
    <div class="card-body">
      <?php if (empty($this->reports)): ?>
        <div class="alert alert-info">
          <?php echo Language::translate('COM_FREECHAT_REPORT_NO_REPORTS'); ?>
        </div>
      <?php else: ?>
        <div class="table-responsive">
          <table class="table table-hover align-middle">
            <thead>
              <tr>
                <th><?php echo Language::translate('COM_FREECHAT_REPORT_NEW'); ?></th>
                <th><?php echo Language::translate('COM_FREECHAT_REPORT_REASON'); ?></th>
                <th><?php echo Language::translate('COM_FREECHAT_TOPICS'); ?></th>
                <th><?php echo Language::translate('COM_FREECHAT_POSTS'); ?></th>
                <th><?php echo Language::translate('COM_FREECHAT_SPACE_STATE'); ?></th>
                <th class="text-end"><?php echo Language::translate('COM_FREECHAT_MODERATION'); ?></th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($this->reports as $report): ?>
                <tr>
                  <td>
                    <span class="badge bg-<?php echo $report->type == 'post' ? 'primary' : ($report->type == 'topic' ? 'info' : 'warning'); ?>">
                      <?php echo strtoupper($report->type); ?>
                    </span>
                    <br>
                    <small><?php echo htmlspecialchars($report->reporter_name); ?></small>
                  </td>
                  <td>
                    <strong><?php echo htmlspecialchars($report->reason); ?></strong>
                    <?php if ($report->details): ?>
                      <br>
                      <small class="text-muted"><?php echo htmlspecialchars($report->details); ?></small>
                    <?php endif; ?>
                  </td>
                  <td>
                    <?php echo date('Y-m-d H:i', strtotime($report->created_at)); ?>
                  </td>
                  <td>
                    <?php if ($report->reviewer_name): ?>
                      <?php echo htmlspecialchars($report->reviewer_name); ?>
                      <br>
                      <small><?php echo date('Y-m-d H:i', strtotime($report->reviewed_at)); ?></small>
                    <?php else: ?>
                      <span class="text-muted">-</span>
                    <?php endif; ?>
                  </td>
                  <td>
                    <span class="badge bg-<?php echo $report->status == 'pending' ? 'warning' : ($report->status == 'resolved' ? 'success' : ($report->status == 'dismissed' ? 'secondary' : 'info')); ?>">
                      <?php echo Language::translate('COM_FREECHAT_REPORT_STATUS_' . strtoupper($report->status)); ?>
                    </span>
                  </td>
                  <td class="text-end">
                    <?php if ($report->status == 'pending'): ?>
                      <a href="index.php?option=freechat&view=reports&task=resolve&id=<?php echo $report->id; ?>" class="btn btn-sm btn-outline-success" onclick="return confirm('Mark as resolved?')">
                        <i class="fa-solid fa-check"></i>
                      </a>
                      <a href="index.php?option=freechat&view=reports&task=dismiss&id=<?php echo $report->id; ?>" class="btn btn-sm btn-outline-secondary" onclick="return confirm('Dismiss this report?')">
                        <i class="fa-solid fa-times"></i>
                      </a>
                    <?php else: ?>
                      <span class="text-muted">-</span>
                    <?php endif; ?>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>
