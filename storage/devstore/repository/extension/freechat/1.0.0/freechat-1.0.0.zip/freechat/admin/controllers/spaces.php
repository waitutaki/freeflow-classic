<?php
/**
 * Freechat Extension - Spaces Controller
 * Admin controller for managing forum spaces
 */

namespace Freeflow\Extension\Freechat\Admin;

defined('_FFEXEC') or die;

use Freeflow\Core\Controller;
use Freeflow\Core\Database;
use Freeflow\Core\Language;
use Freeflow\Core\User;
use Freeflow\Core\Application;

/**
 * Spaces Controller
 */
class SpacesController extends Controller
{
  /**
   * Display list of spaces
   */
  public function display()
  {
    $this->checkPermission('freechat.spaces.create');
    
    $db = Database::getInstance();
    
    $query = $db->getQuery(true)
      ->select('*')
      ->from('#_ext_freechat_spaces')
      ->order('ordering ASC');
    
    $spaces = $db->setQuery($query)->loadObjectList();
    
    $this->view->assign('spaces', $spaces);
    $this->view->setLayout('default');
    $this->view->display();
  }
  
  /**
   * New space form
   */
  public function add()
  {
    $this->checkPermission('freechat.spaces.create');
    
    $this->view->setLayout('edit');
    $this->view->display();
  }
  
  /**
   * Edit space form
   */
  public function edit()
  {
    $this->checkPermission('freechat.spaces.manage');
    
    $id = $this->input->getInt('id', 0);
    
    if (!$id) {
      Application::enqueueMessage(Language::translate('COM_FREECHAT_NOT_FOUND'), 'error');
      $this->redirect('index.php?option=freechat&view=spaces');
    }
    
    $db = Database::getInstance();
    
    $space = $db->getQuery(true)
      ->select('*')
      ->from('#_ext_freechat_spaces')
      ->where('id = ' . $id)
      ->loadObject();
    
    if (!$space) {
      Application::enqueueMessage(Language::translate('COM_FREECHAT_NOT_FOUND'), 'error');
      $this->redirect('index.php?option=freechat&view=spaces');
    }
    
    $this->view->assign('space', $space);
    $this->view->setLayout('edit');
    $this->view->display();
  }
  
  /**
   * Save space (create or update)
   */
  public function save()
  {
    $this->checkPermission('freechat.spaces.create');
    
    $id = $this->input->getInt('id', 0);
    $title = $this->input->getString('title', '');
    $description = $this->input->getRaw('description', '');
    $ordering = $this->input->getInt('ordering', 0);
    $state = $this->input->getInt('state', 1);
    
    if (empty($title)) {
      Application::enqueueMessage(Language::translate('COM_FREECHAT_ERROR_INVALID_INPUT'), 'error');
      $this->redirect('index.php?option=freechat&view=spaces&task=add');
    }
    
    $db = Database::getInstance();
    $user = User::getInstance();
    $now = date('Y-m-d H:i:s');
    
    $data = [
      'title' => $title,
      'slug' => $this->generateSlug($title),
      'description' => $description,
      'ordering' => $ordering,
      'state' => $state,
      'modified_at' => $now,
      'modified_by' => $user->id
    ];
    
    if ($id) {
      // Update existing space
      $data['id'] = $id;
      $result = $db->update('#_ext_freechat_spaces', $data, 'id');
    } else {
      // Create new space
      $data['created_at'] = $now;
      $data['created_by'] = $user->id;
      $result = $db->insert('#_ext_freechat_spaces', $data);
      $id = $db->insertid();
    }
    
    if ($result === false) {
      Application::enqueueMessage(Language::translate('COM_FREECHAT_ERROR'), 'error');
      $this->redirect('index.php?option=freechat&view=spaces');
    }
    
    Application::enqueueMessage(Language::translate('COM_FREECHAT_SPACE_SAVED'), 'success');
    $this->redirect('index.php?option=freechat&view=spaces');
  }
  
  /**
   * Delete space
   */
  public function delete()
  {
    $this->checkPermission('freechat.spaces.manage');
    
    $id = $this->input->getInt('id', 0);
    
    if (!$id) {
      Application::enqueueMessage(Language::translate('COM_FREECHAT_NOT_FOUND'), 'error');
      $this->redirect('index.php?option=freechat&view=spaces');
    }
    
    // Check if space has categories
    $db = Database::getInstance();
    
    $count = $db->getQuery(true)
      ->select('COUNT(*)')
      ->from('#_ext_freechat_categories')
      ->where('space_id = ' . $id)
      ->loadResult();
    
    if ($count > 0) {
      Application::enqueueMessage('Cannot delete space with categories. Delete categories first.', 'error');
      $this->redirect('index.php?option=freechat&view=spaces');
    }
    
    $result = $db->delete('#_ext_freechat_spaces', ['id' => $id]);
    
    if ($result === false) {
      Application::enqueueMessage(Language::translate('COM_FREECHAT_ERROR'), 'error');
    } else {
      Application::enqueueMessage(Language::translate('COM_FREECHAT_SPACE_DELETED'), 'success');
    }
    
    $this->redirect('index.php?option=freechat&view=spaces');
  }
  
  /**
   * Publish/Unpublish space (toggle)
   */
  public function toggleState()
  {
    $this->checkPermission('freechat.spaces.manage');
    
    $id = $this->input->getInt('id', 0);
    $newState = $this->input->getInt('state', 0);
    
    if (!$id) {
      echo json_encode(['success' => false, 'message' => 'Invalid ID']);
      return;
    }
    
    $db = Database::getInstance();
    
    $result = $db->update('#_ext_freechat_spaces', 
      ['state' => $newState, 'modified_at' => date('Y-m-d H:i:s')],
      ['id' => $id]
    );
    
    echo json_encode([
      'success' => $result !== false,
      'newState' => $newState,
      'icon' => $newState ? 'fa-circle-check text-success' : 'fa-circle-xmark text-danger'
    ]);
  }
  
  /**
   * Generate URL slug from title
   */
  private function generateSlug($title)
  {
    $slug = strtolower(trim($title));
    $slug = preg_replace('/[^a-z0-9-]/', '-', $slug);
    $slug = preg_replace('/-+/', '-', $slug);
    $slug = trim($slug, '-');
    
    // Ensure uniqueness
    $db = Database::getInstance();
    $i = 1;
    $originalSlug = $slug;
    
    while (true) {
      $exists = $db->getQuery(true)
        ->select('COUNT(*)')
        ->from('#_ext_freechat_spaces')
        ->where('slug = ' . $db->quote($slug))
        ->loadResult();
      
      if (!$exists) {
        break;
      }
      
      $slug = $originalSlug . '-' . $i++;
    }
    
    return $slug;
  }
}
