<?php
/**
 * Freechat Extension - Site Controller
 * Main forum index controller
 */

namespace Freeflow\Extension\Freechat\Site;

defined('_FFEXEC') or die;

use Freeflow\Core\Controller;
use Freeflow\Core\Database;
use Freeflow\Core\Language;
use Freeflow\Core\User;
use Freeflow\Core\Application;

class IndexController extends Controller
{
  /**
   * Display forum index (list of spaces, categories, forums)
   */
  public function display()
  {
    $db = Database::getInstance();
    
    // Get all spaces with their categories and forums
    $spaces = $db->getQuery(true)
      ->select('*')
      ->from('#_ext_freechat_spaces')
      ->where('state = 1')
      ->order('ordering ASC')
      ->loadObjectList();
    
    // Get categories for each space
    foreach ($spaces as &$space) {
      $space->categories = $db->getQuery(true)
        ->select('*')
        ->from('#_ext_freechat_categories')
        ->where('space_id = ' . $space->id)
        ->where('state = 1')
        ->order('ordering ASC')
        ->loadObjectList();
      
      // Get forums for each category
      foreach ($space->categories as &$category) {
        $category->forums = $db->getQuery(true)
          ->select('f.*')
          ->select('(SELECT COUNT(*) FROM #_ext_freechat_topics WHERE forum_id = f.id AND state IN (\'open\',\'locked\')) as topic_count')
          ->select('(SELECT COUNT(*) FROM #_ext_freechat_posts p INNER JOIN #_ext_freechat_topics t ON p.topic_id = t.id WHERE t.forum_id = f.id AND p.state = \'published\') as post_count')
          ->select('(SELECT MAX(last_post_at) FROM #_ext_freechat_topics WHERE forum_id = f.id) as last_activity')
          ->from('#_ext_freechat_forums f')
          ->where('f.category_id = ' . $category->id)
          ->where('f.state = 1')
          ->order('f.ordering ASC')
          ->loadObjectList();
      }
    }
    
    $this->view->assign('spaces', $spaces);
    $this->view->setLayout('default');
    $this->view->display();
  }
}
