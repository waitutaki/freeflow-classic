<?php
/**
 * Freechat Extension - Admin View - Space Edit Form
 */

defined('_FFEXEC') or die;

$space = isset($this->space) ? $this->space : null;
$isEdit = !empty($space);
?>
<div class="container-fluid">
  <div class="row mb-3">
    <div class="col">
      <h1 class="h3 mb-0">
        <i class="fa-solid fa-comments me-2"></i>
        <?php echo $isEdit ? Language::translate('COM_FREECHAT_SPACE_EDIT') : Language::translate('COM_FREECHAT_SPACE_NEW'); ?>
      </h1>
    </div>
  </div>

  <div class="card">
    <div class="card-body">
      <form action="index.php?option=freechat&view=spaces&task=save" method="post" class="needs-validation" novalidate>
        <?php if ($isEdit): ?>
          <input type="hidden" name="id" value="<?php echo $space->id; ?>">
        <?php endif; ?>

        <div class="row mb-3">
          <div class="col-md-6">
            <label for="title" class="form-label"><?php echo Language::translate('COM_FREECHAT_SPACE_TITLE'); ?> *</label>
            <input type="text" class="form-control" id="title" name="title" value="<?php echo $space->title ?? ''; ?>" required>
            <div class="invalid-feedback">Please enter a title</div>
          </div>
        </div>

        <div class="row mb-3">
          <div class="col-md-6">
            <label for="description" class="form-label"><?php echo Language::translate('COM_FREECHAT_SPACE_DESCRIPTION'); ?></label>
            <textarea class="form-control" id="description" name="description" rows="3"><?php echo $space->description ?? ''; ?></textarea>
          </div>
        </div>

        <div class="row mb-3">
          <div class="col-md-3">
            <label for="ordering" class="form-label"><?php echo Language::translate('COM_FREECHAT_SPACE_ORDERING'); ?></label>
            <input type="number" class="form-control" id="ordering" name="ordering" value="<?php echo $space->ordering ?? 0; ?>" min="0">
          </div>
          <div class="col-md-3">
            <label for="state" class="form-label"><?php echo Language::translate('COM_FREECHAT_SPACE_STATE'); ?></label>
            <select class="form-select" id="state" name="state">
              <option value="1" <?php echo ($space->state ?? 1) == 1 ? 'selected' : ''; ?>>
                <?php echo Language::translate('COM_FREECHAT_SPACE_PUBLISHED'); ?>
              </option>
              <option value="0" <?php echo ($space->state ?? 1) == 0 ? 'selected' : ''; ?>>
                <?php echo Language::translate('COM_FREECHAT_SPACE_UNPUBLISHED'); ?>
              </option>
            </select>
          </div>
        </div>

        <div class="row">
          <div class="col">
            <button type="submit" class="btn btn-primary">
              <i class="fa-solid fa-check me-1"></i>
              <?php echo Language::translate('COM_FREECHAT_SAVE'); ?>
            </button>
            <a href="index.php?option=freechat&view=spaces" class="btn btn-secondary">
              <i class="fa-solid fa-xmark me-1"></i>
              <?php echo Language::translate('COM_FREECHAT_CANCEL'); ?>
            </a>
          </div>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
(function() {
  'use strict';
  var forms = document.querySelectorAll('.needs-validation');
  Array.prototype.slice.call(forms).forEach(function(form) {
    form.addEventListener('submit', function(event) {
      if (!form.checkValidity()) {
        event.preventDefault();
        event.stopPropagation();
      }
      form.classList.add('was-validated');
    }, false);
  });
})();
</script>
